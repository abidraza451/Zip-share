package com.mashreq.obms_neofxrates_api.model;

import lombok.Data;

@Data
public class HmacRequestQuote {
    private String clOrderId;
    private String symbol;
    private Number amount;
    private String dealtCurrency;
    private String side;
    private Boolean rfq;
    private Number expiry;
    private String priceType;
    private String customerAccount;
    private String customerOrg;
    private String nearValueDate;
}
