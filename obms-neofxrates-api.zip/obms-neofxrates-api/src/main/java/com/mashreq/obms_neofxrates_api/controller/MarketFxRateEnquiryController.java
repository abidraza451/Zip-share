package com.mashreq.obms_neofxrates_api.controller;

import com.mashreq.obms_neofxrates_api.dto.RequestQuoteResponse;
import com.mashreq.obms_neofxrates_api.model.HmacRequestQuote;
import com.mashreq.obms_neofxrates_api.serivce.RequestQuoteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/request-quote")
public class MarketFxRateEnquiryController {

    @Autowired
    private RequestQuoteService requestQuoteService;

    @PostMapping
    public RequestQuoteResponse requestQuote(@RequestBody HmacRequestQuote hmacRequestQuote) {
        return requestQuoteService.getRequestQuoteAPi(hmacRequestQuote);
    }

}
