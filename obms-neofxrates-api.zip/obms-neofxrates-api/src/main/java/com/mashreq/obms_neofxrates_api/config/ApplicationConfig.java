package com.mashreq.obms_neofxrates_api.config;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties(prefix = "app")
@Getter
@Setter
public class ApplicationConfig {

    private String baseUrl;

    private Hmac hmac;
    @Getter
    @Setter
    public static  class Hmac {
        private String userId;
        private String secret;
    }

}
