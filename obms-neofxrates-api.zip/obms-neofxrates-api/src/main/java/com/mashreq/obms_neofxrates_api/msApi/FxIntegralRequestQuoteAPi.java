package com.mashreq.obms_neofxrates_api.msApi;

import com.mashreq.obms_neofxrates_api.config.ApplicationConfig;
import com.mashreq.obms_neofxrates_api.dto.RequestQuoteResponse;
import com.mashreq.obms_neofxrates_api.model.HmacRequestQuote;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class FxIntegralRequestQuoteAPi {

    @Autowired
    private ApplicationConfig applicationConfig;

    public RequestQuoteResponse MsRequestQuoteAPi(HmacRequestQuote hmacRequestQuote) {

        String url = applicationConfig.getBaseUrl() + "/v2/rfs";
        System.out.println("MsRequestQuoteAPi: " + url);

        try {

            RestTemplate restTemplate = new RestTemplate();

            HttpHeaders headers = new HttpHeaders();
            headers.add("Content-Type", "application/json");
            headers.add("Cookie", "sso_sticky_session_apigateway=apigateway1");

            HttpEntity<?> requestEntity =
                    new HttpEntity<>(hmacRequestQuote, headers);

            System.out.println("MsRequestQuoteAPi: " + requestEntity.toString());

            ResponseEntity<RequestQuoteResponse> responseEntity =
                    restTemplate.exchange(
                            url,
                            HttpMethod.POST,
                            requestEntity,
                            RequestQuoteResponse.class
                    );

            return responseEntity.getBody();

        } catch (Exception exception) {

            throw exception;
        }
    }
}