package com.mashreq.obms_neofxrates_api.dto;

import lombok.*;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class RequestQuoteResponse {
    private String clOrderId;
    private String requestId;
    private String event;
}
