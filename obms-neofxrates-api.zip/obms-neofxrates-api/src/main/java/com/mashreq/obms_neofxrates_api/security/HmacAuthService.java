package com.mashreq.obms_neofxrates_api.security;

import com.mashreq.obms_neofxrates_api.config.ApplicationConfig;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Base64;

@Service
public class HmacAuthService {

    @Autowired
    private ApplicationConfig applicationConfig;

    public String generateDigest(String body){

        try{
            MessageDigest digest = MessageDigest.getInstance("SHA-256");

            byte[] hash =digest.digest(
                    body.getBytes(StandardCharsets.UTF_8)

            );
            return Base64.getEncoder().encodeToString(hash);
        }
        catch (Exception exception){
            throw new RuntimeException("Failed to genrate request digest", exception);
        }
    }

    public String generateDate(){
        return ZonedDateTime.now().format(DateTimeFormatter.RFC_1123_DATE_TIME);
    }

    public String generateRequestLine(String method, String path){
        return method + " " + path + " HTTP/1.1";
    }

    public String generateSignature(String date, String requestLine, String digest){

        try{
            String signingString = "date: " +date+ "\n"+
                    requestLine + "\n" +
                    "digest: " +digest;

            String secret =applicationConfig.getHmac().getSecret();

            javax.crypto.Mac mac = javax.crypto.Mac.getInstance("HmacSHA256");

            javax.crypto.spec.SecretKeySpec secretKey =
                    new javax.crypto.spec.SecretKeySpec(secret.getBytes(StandardCharsets.UTF_8),"HmacSHA256");
            mac.init(secretKey);
            byte[] hmacBytes =mac.doFinal(signingString.getBytes(StandardCharsets.UTF_8));

            return Base64.getEncoder().encodeToString(hmacBytes);


        }
        catch(Exception exception){
            throw new RuntimeException("Failed to generate HMAC signature", exception);
        }
    }


}
