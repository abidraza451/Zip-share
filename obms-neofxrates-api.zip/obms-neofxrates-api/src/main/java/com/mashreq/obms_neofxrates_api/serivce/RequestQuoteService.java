package com.mashreq.obms_neofxrates_api.serivce;

import com.mashreq.obms_neofxrates_api.dto.RequestQuoteResponse;
import com.mashreq.obms_neofxrates_api.model.HmacRequestQuote;
import com.mashreq.obms_neofxrates_api.msApi.FxIntegralRequestQuoteAPi;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class RequestQuoteService {

    @Autowired
    private FxIntegralRequestQuoteAPi fxIntegralRequestQuoteAPi;

    public RequestQuoteResponse getRequestQuoteAPi(HmacRequestQuote hmacRequestQuote) {
        return fxIntegralRequestQuoteAPi.MsRequestQuoteAPi(hmacRequestQuote);
    }
}