package com.mashreq.obms.neofxrates;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ObmsNeofxratesApiApplication {

    public static void main(String[] args) {
        SpringApplication.run(ObmsNeofxratesApiApplication.class, args);
    }
}
