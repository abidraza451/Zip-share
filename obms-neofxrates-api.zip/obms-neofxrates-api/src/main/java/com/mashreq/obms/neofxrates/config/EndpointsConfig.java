package com.mashreq.obms.neofxrates.config;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties(prefix = "endpoints")
@Getter
@Setter
public class EndpointsConfig {

    private String ssoLogin;
    private String reqQuote;
    private String queryByServerId;
    private String queryByClientId;
    private String acceptQuote;
    private String placeOrder;
    private String queryOrder;
    private String bookTrade;
}