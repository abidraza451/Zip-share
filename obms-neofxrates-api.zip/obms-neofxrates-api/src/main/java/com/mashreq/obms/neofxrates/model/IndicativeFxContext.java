package com.mashreq.obms.neofxrates.model;

import lombok.Data;

import java.util.LinkedHashMap;
import java.util.Map;

@Data
public class IndicativeFxContext {
    private String ssoToken;
    private String clOrderId;
    private String requestId;
    private String transactionId;
    private String quoteId;
    private String event;
}
