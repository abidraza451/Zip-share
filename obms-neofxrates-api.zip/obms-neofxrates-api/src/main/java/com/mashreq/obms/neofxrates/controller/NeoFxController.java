package com.mashreq.obms.neofxrates.controller;

import com.mashreq.obms.neofxrates.dto.DealBookingRequest;
import com.mashreq.obms.neofxrates.dto.DealBookingResponse;
import com.mashreq.obms.neofxrates.dto.DirectDealRequest;
import com.mashreq.obms.neofxrates.dto.DirectDealResponse;
import com.mashreq.obms.neofxrates.dto.IndicativeFxRateEnquiryRequest;
import com.mashreq.obms.neofxrates.dto.TsdFxRateEnquiryResponse;
import com.mashreq.obms.neofxrates.service.DealBookingService;
import com.mashreq.obms.neofxrates.service.DirectDealService;
import com.mashreq.obms.neofxrates.service.IndicativeFxRateService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/neoFx")
@RequiredArgsConstructor
public class NeoFxController {

    private final IndicativeFxRateService indicativeFxRateService;
    private final DealBookingService dealBookingService;
    private final DirectDealService directDealService;

    @PostMapping("/indicativeFxRateEnquiry")
    public ResponseEntity<TsdFxRateEnquiryResponse> acceptQuote(
            @RequestBody IndicativeFxRateEnquiryRequest request) {

        return indicativeFxRateService.fetchFxRate(request);
    }
    @PostMapping("/dealBooking")
    public ResponseEntity<DealBookingResponse> dealBooking(
            @RequestBody DealBookingRequest request) {

        return dealBookingService.dealBooking(request);
    }


    @PostMapping("/directDeal")
    public ResponseEntity<DirectDealResponse> directDeal(
            @RequestBody DirectDealRequest request) {

        return directDealService.directDeal(request);
    }

}
