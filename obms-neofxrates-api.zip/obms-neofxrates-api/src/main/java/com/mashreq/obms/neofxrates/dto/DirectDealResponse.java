package com.mashreq.obms.neofxrates.dto;

import lombok.Data;

import java.util.Map;

/**
 * Public response wrapper for Direct Deal.
 *
 * The Integral Book Trade response is returned under data and the incoming
 * Direct Deal request is returned under requestBody.
 */
@Data
public class DirectDealResponse {

    private DirectDealBookTradeResponse data;
    private Map<String, Object> requestBody;
}
