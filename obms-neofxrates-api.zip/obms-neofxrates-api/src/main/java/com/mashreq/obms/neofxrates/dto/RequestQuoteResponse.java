package com.mashreq.obms.neofxrates.dto;

import lombok.Data;

@Data
public class RequestQuoteResponse {
    private String clOrderId;
    private String requestId;
    private String status;
    private String event;
}
