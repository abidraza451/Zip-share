package com.mashreq.obms.neofxrates.repository;

import com.mashreq.obms.neofxrates.entity.TraditionalCurrencyPairDirection;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface TraditionalCurrencyPairDirectionRepository
        extends JpaRepository<TraditionalCurrencyPairDirection, Long> {

    Optional<TraditionalCurrencyPairDirection> findByBaseCurrencyAndQuoteCurrency(
            String baseCurrency,
            String quoteCurrency
    );
}
