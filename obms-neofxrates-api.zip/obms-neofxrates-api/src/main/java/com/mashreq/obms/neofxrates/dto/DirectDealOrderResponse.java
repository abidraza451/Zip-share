package com.mashreq.obms.neofxrates.dto;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Map;

/**
 * Integral order response used by both Place Order and Query Order.
 *
 * Integral can return additional order fields depending on the endpoint and
 * order state. Unknown fields are intentionally ignored so a valid Integral
 * response cannot fail only because a new/non-required field was added.
 */
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class DirectDealOrderResponse {

    private String orderId;
    private String coId;
    private String status;
    private String symbol;
    private String side;
    private BigDecimal size;

    /** Filled quantity returned by Query Order. */
    @JsonAlias({"filledSize", "filledQty"})
    private BigDecimal cumQty;

    /** Average execution price returned after the order is filled. */
    @JsonAlias({"avgPrice", "averagePrice"})
    private BigDecimal averagePrice;

    private String tradeDate;

    // Fields returned by Place Order and/or Query Order.
    private String type;
    private String timeInForce;
    private String currency;
    private String org;
    private String customerOrgName;
    private String account;
    private String clientOrderTime;
    private String tradeChannel;
    private String valueDate;
    private String userFullName;
    private String action;

    /** Reason returned by Integral when an order is rejected/cancelled. */
    private String reason;
    private Map<String, String> customParameters;
}
