package com.mashreq.obms.neofxrates.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mashreq.obms.neofxrates.dto.AcceptQuoteRequest;
import com.mashreq.obms.neofxrates.dto.DealBookingRequest;
import com.mashreq.obms.neofxrates.dto.DealBookingRequestBody;
import com.mashreq.obms.neofxrates.dto.DealBookingResponse;
import com.mashreq.obms.neofxrates.exception.RequestQuoteException;
import com.mashreq.obms.neofxrates.msApi.FxIntegralAcceptQuoteApi;
import com.mashreq.obms.neofxrates.msApi.FxIntegralQueryQuoteApi;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientResponseException;

import java.util.LinkedHashMap;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class DealBookingService {

    private final FxIntegralAcceptQuoteApi acceptQuoteApi;
    private final FxIntegralQueryQuoteApi queryQuoteApi;
    private final ObjectMapper objectMapper;

    public ResponseEntity<DealBookingResponse> dealBooking(DealBookingRequest request) {
        validateReq(request);

        // Accept Quote - Integral can legitimately return 2xx with an empty body.
        callAcceptQuote(request);

        // Keep the same processing window used by the Indicative FX Rate flow.
        waitBeforeQueryQuote();

        // Query Quote exactly once, using the server request ID.
        ResponseEntity<String> queryQuoteResponse = callQueryQuote(request.getRequestId());

        DealBookingResponse response = buildDealBookingResponse(
                queryQuoteResponse.getBody(), request);

        return ResponseEntity.status(queryQuoteResponse.getStatusCode()).body(response);
    }

    private void callAcceptQuote(DealBookingRequest request) {
        AcceptQuoteRequest acceptRequest = AcceptQuoteRequest.builder()
                .quoteId(request.getQuoteId())
                .side(request.getSide())
                .symbol(request.getSymbol())
                .dealtCurrency(request.getDealtCurrency())
                .transactionId(request.getTransactionId())
                .clOrderId(request.getClOrderId())
                .rfq(request.getRfq())
                .build();

        try {
            ResponseEntity<String> response =
                    acceptQuoteApi.acceptQuote(request.getRequestId(), acceptRequest);

            if (response == null) {
                throw new RequestQuoteException("ACCEPT_QUOTE", HttpStatus.BAD_GATEWAY,
                        "Integral returned empty Accept Quote response");
            }

            if (!response.getStatusCode().is2xxSuccessful()) {
                throw new RequestQuoteException("ACCEPT_QUOTE", response.getStatusCode(),
                        "Integral Accept Quote failed");
            }

            // Accept Quote is asynchronous and may legitimately return 202/2xx
            // without a response body. Only the HTTP status is validated here.
        } catch (RequestQuoteException ex) {
            throw ex;
        } catch (RestClientResponseException ex) {
            throw new RequestQuoteException("ACCEPT_QUOTE", ex.getStatusCode(),
                    "Integral Accept Quote returned HTTP " + ex.getStatusCode().value());
        } catch (Exception ex) {
            throw new RequestQuoteException("ACCEPT_QUOTE", HttpStatus.BAD_GATEWAY,
                    "Unable to call Integral Accept Quote: " + ex.getMessage());
        }
    }

    private ResponseEntity<String> callQueryQuote(String requestId) {
        try {
            ResponseEntity<String> response = queryQuoteApi.queryByServerId(requestId);

            if (response == null) {
                throw new RequestQuoteException("QUERY_QUOTE", HttpStatus.BAD_GATEWAY,
                        "Integral returned empty Query Quote response");
            }

            if (!response.getStatusCode().is2xxSuccessful()) {
                throw new RequestQuoteException("QUERY_QUOTE", response.getStatusCode(),
                        "Integral Query Quote failed");
            }

            if (response.getBody() == null || response.getBody().isBlank()) {
                throw new RequestQuoteException("QUERY_QUOTE", HttpStatus.BAD_GATEWAY,
                        "Integral returned empty Query Quote body");
            }

            return response;
        } catch (RequestQuoteException ex) {
            throw ex;
        } catch (RestClientResponseException ex) {
            throw new RequestQuoteException("QUERY_QUOTE", ex.getStatusCode(),
                    "Integral Query Quote returned HTTP " + ex.getStatusCode().value());
        } catch (Exception ex) {
            throw new RequestQuoteException("QUERY_QUOTE", HttpStatus.BAD_GATEWAY,
                    "Unable to call Integral Query Quote: " + ex.getMessage());
        }
    }

    private DealBookingResponse buildDealBookingResponse(
            String integralResponse, DealBookingRequest request) {

        try {
            Map<String, Object> data = objectMapper.readValue(
                    integralResponse,
                    new TypeReference<LinkedHashMap<String, Object>>() {
                    });

            if (data == null || data.isEmpty()) {
                throw new RequestQuoteException("QUERY_QUOTE", HttpStatus.BAD_GATEWAY,
                        "Integral Query Quote response is empty");
            }

            DealBookingResponse response = new DealBookingResponse();
            response.setData(data);
            response.setRequestBody(toResponseRequestBody(request));
            return response;

        } catch (RequestQuoteException ex) {
            throw ex;
        } catch (Exception ex) {
            throw new RequestQuoteException("QUERY_QUOTE", HttpStatus.BAD_GATEWAY,
                    "Unable to parse Integral Query Quote response: " + ex.getMessage());
        }
    }

    private DealBookingRequestBody toResponseRequestBody(DealBookingRequest request) {
        return new DealBookingRequestBody(
                request.getCif(),
                request.getQuoteId(),
                request.getRefNo(),
                request.getRfq(),
                request.getSide(),
                request.getSource());
    }

    private void waitBeforeQueryQuote() {
        try {
            Thread.sleep(2000);
        } catch (InterruptedException ex) {
            Thread.currentThread().interrupt();
            throw new RequestQuoteException("QUERY_QUOTE", HttpStatus.INTERNAL_SERVER_ERROR,
                    "Interrupted while waiting for Query Quote");
        }
    }

    private void validateReq(DealBookingRequest request) {
        if (request == null) {
            throw new RequestQuoteException("VALIDATION", HttpStatus.BAD_REQUEST,
                    "Request body is required");
        }
        require(request.getRequestId(), "requestId");
        require(request.getQuoteId(), "quoteId");
        require(request.getSide(), "side");
        require(request.getSymbol(), "symbol");
        require(request.getDealtCurrency(), "dealtCurrency");
        require(request.getTransactionId(), "transactionId");
        require(request.getClOrderId(), "clOrderId");
        if (request.getRfq() == null) {
            throw new RequestQuoteException("VALIDATION", HttpStatus.BAD_REQUEST,
                    "rfq is required");
        }
    }

    private void require(String value, String field) {
        if (value == null || value.isBlank()) {
            throw new RequestQuoteException("VALIDATION", HttpStatus.BAD_REQUEST,
                    field + " is required");
        }
    }
}
