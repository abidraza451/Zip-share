package com.mashreq.obms.neofxrates.msApi;

import com.mashreq.obms.neofxrates.config.ApplicationConfig;
import com.mashreq.obms.neofxrates.config.EndpointsConfig;
import com.mashreq.obms.neofxrates.dto.DirectDealPlaceOrderRequest;
import com.mashreq.obms.neofxrates.hmac.IntegralHmacInterceptor;
import jakarta.websocket.EndpointConfig;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
@RequiredArgsConstructor
public class FxIntegralPlaceOrderApi {

    private final ApplicationConfig applicationConfig;
    private final EndpointsConfig endpointsConfig;
    private final RestTemplate restTemplate;

    /** Existing HMAC-authenticated Place Order call. */
    public ResponseEntity<String> placeOrder(DirectDealPlaceOrderRequest request) {
        return exchange(request, null);
    }

    /** Direct Deal Place Order using the SSO_TOKEN returned by Direct Deal login. */
    public ResponseEntity<String> placeOrderWithSso(DirectDealPlaceOrderRequest request, String ssoToken) {
        return exchange(request, ssoToken);
    }

    private ResponseEntity<String> exchange(
            DirectDealPlaceOrderRequest request, String ssoToken) {


        String url = applicationConfig.getBaseUrl() + endpointsConfig.getPlaceOrder();
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setAccept(java.util.List.of(MediaType.APPLICATION_JSON));

        if (ssoToken != null && !ssoToken.isBlank()) {
            headers.set("SSO_TOKEN", ssoToken);
            headers.set(IntegralHmacInterceptor.SKIP_HMAC_HEADER, "true");
        }

        return restTemplate.exchange(
                url,
                HttpMethod.POST,
                new HttpEntity<>(request, headers),
                String.class);
    }
}
