package com.mashreq.obms.neofxrates.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

import java.util.Set;

/**
 * Public representation of the Integral Book Trade response.
 */
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class DirectDealBookTradeResponse {

    private String tradeId;
    private String createdTime;
    private String clientRequestId;

    /**
     * Returns the top-level response field names so the public requestBody can
     * avoid returning the same values twice.
     */
    @JsonIgnore
    public Set<String> getResponseFieldNames() {
        return Set.of("tradeId", "createdTime", "clientRequestId");
    }
}
