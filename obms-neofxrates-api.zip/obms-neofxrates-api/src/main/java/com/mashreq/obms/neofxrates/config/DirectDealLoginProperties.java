package com.mashreq.obms.neofxrates.config;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties(prefix = "app.direct-deal.login")
@Getter
@Setter
public class DirectDealLoginProperties {

    private String user;
    private String pass;
    private String org;
}
