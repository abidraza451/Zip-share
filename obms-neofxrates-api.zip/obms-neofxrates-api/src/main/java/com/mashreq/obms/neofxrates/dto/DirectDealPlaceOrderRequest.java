package com.mashreq.obms.neofxrates.dto;

import lombok.Builder;
import lombok.Getter;

import java.math.BigDecimal;
import java.util.Map;

@Getter
@Builder
public class DirectDealPlaceOrderRequest {

    private String coId;
    private String type;
    private String symbol;
    private String side;
    private BigDecimal size;
    private String currency;
    private String timeInForce;
    private String valueDate;
    private String org;
    private String account;
    private Map<String, String> customParameters;
}
