package com.mashreq.obms.neofxrates.dto;

public class QueryQuoteResponse {
}
