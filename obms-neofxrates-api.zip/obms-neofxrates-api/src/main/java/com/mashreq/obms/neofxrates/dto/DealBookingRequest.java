package com.mashreq.obms.neofxrates.dto;

import lombok.Data;

@Data
public class DealBookingRequest {

    private String requestId;
    private String quoteId;
    private String side;
    private String symbol;
    private String dealtCurrency;
    private String transactionId;
    private String clOrderId;
    private Boolean rfq;
    private String cif;
    private String refNo;
    private String source;
}
