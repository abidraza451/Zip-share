package com.mashreq.obms.neofxrates.dto;

import lombok.Data;

@Data
public class LoginRequest {
    private String user;
    private String pass;
    private String org;
}
