package com.mashreq.obms.neofxrates.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

import java.util.Map;

/**
 * Response contract exposed by the indicative FX rate enquiry API.
 *
 * <p>All TSD data fields that belong to the data object, including
 * {@code cachedRate}, are kept inside {@code data}. Normal Java JSON-compatible
 * types are used to avoid JsonNode introspection properties leaking into the
 * API response.</p>
 */
@Data
@JsonInclude(JsonInclude.Include.ALWAYS)
public class TsdFxRateEnquiryResponse {

    private Map<String, Object> data;
    private QueryQuoteRequestBody requestBody;
}
