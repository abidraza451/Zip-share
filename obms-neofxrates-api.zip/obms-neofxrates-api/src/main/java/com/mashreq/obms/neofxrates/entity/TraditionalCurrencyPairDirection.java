package com.mashreq.obms.neofxrates.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(
        name = "currency_pair",
        uniqueConstraints = @UniqueConstraint(
                name = "unique_pair",
                columnNames = {"base_currency", "quote_currency"}
        )
)
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class TraditionalCurrencyPairDirection {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "base_currency", nullable = false, length = 3)
    private String baseCurrency;

    @Column(name = "quote_currency", nullable = false, length = 3)
    private String quoteCurrency;
}
