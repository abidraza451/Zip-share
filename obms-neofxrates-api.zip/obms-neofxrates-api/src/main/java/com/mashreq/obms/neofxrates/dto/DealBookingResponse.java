package com.mashreq.obms.neofxrates.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

import java.util.Map;

/**
 * Response contract exposed by the Deal Booking API.
 *
 * <p>The successful Integral Query Quote response is wrapped inside
 * {@code data}, while the original Deal Booking request is returned as
 * {@code requestBody}, matching the response pattern used by the
 * Indicative FX Rate Enquiry API.</p>
 */
@Data
@JsonInclude(JsonInclude.Include.ALWAYS)
public class DealBookingResponse {

    private Map<String, Object> data;
    private DealBookingRequestBody requestBody;
}
