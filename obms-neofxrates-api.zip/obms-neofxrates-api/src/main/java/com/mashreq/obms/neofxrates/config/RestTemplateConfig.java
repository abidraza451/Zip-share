package com.mashreq.obms.neofxrates.config;

import com.mashreq.obms.neofxrates.hmac.IntegralHmacInterceptor;
import com.mashreq.obms.neofxrates.hmac.IntegralHmacProperties;
import com.mashreq.obms.neofxrates.hmac.IntegralHmacService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

@Configuration
public class RestTemplateConfig {

    @Bean
    public ObjectMapper objectMapper() {
        return new ObjectMapper();
    }

    @Bean
    public IntegralHmacService integralHmacService(
            IntegralHmacProperties hmacProperties) {

        return new IntegralHmacService(hmacProperties);
    }

    @Bean
    public RestTemplate restTemplate(
            IntegralHmacProperties hmacProperties,
            IntegralHmacService hmacService) {

        // Use RestTemplate default message converters for request/response serialization.
        // IntegralHmacInterceptor is responsible only for Integral HMAC headers.
        RestTemplate restTemplate = new RestTemplate();

        restTemplate.getInterceptors().add(
                new IntegralHmacInterceptor(
                        hmacProperties,
                        hmacService));

        return restTemplate;
    }
}
