package com.mashreq.obms.neofxrates.config;

import com.mashreq.obms.neofxrates.hmac.IntegralHmacInterceptor;
import com.mashreq.obms.neofxrates.hmac.IntegralHmacProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

@Configuration
public class RestTemplateConfig {

    @Bean
    public RestTemplate restTemplate(IntegralHmacProperties hmacProperties) {
        RestTemplate restTemplate = new RestTemplate();
        restTemplate.getInterceptors().add(
                new IntegralHmacInterceptor(hmacProperties));
        return restTemplate;
    }
}
