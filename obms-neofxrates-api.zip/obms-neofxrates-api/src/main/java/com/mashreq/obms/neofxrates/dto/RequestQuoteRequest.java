package com.mashreq.obms.neofxrates.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RequestQuoteRequest {
    private String clOrderId;
    private String symbol;
    private Number amount;
    private String dealtCurrency;
    private String side;
    private Boolean rfq = true;
    private Number expiry = 120;
    private String priceType = "Spot";
    private String customerAccount = "NEOFX_UAE_CIBG_Regular";
    private String customerOrg = "NEOFX_UAE_CIBG_Regular";
    private String nearValueDate = "SPOT";

    /**
     * Builds the Integral Request Quote payload. The symbol must be supplied by
     * the currency-pair direction configured in the database; it is intentionally
     * not hard-coded here.
     */
    public RequestQuoteRequest reqQuotecalculate(IndicativeFxRateEnquiryRequest request, String symbol) {
        if (request == null) {
            throw new IllegalArgumentException("request cannot be null");
        }
        if (symbol == null || symbol.isBlank()) {
            throw new IllegalArgumentException("symbol cannot be null or blank");
        }

        RequestQuoteRequest requestQuoteRequest = new RequestQuoteRequest();
        requestQuoteRequest.setClOrderId(request.getRefNo());
        requestQuoteRequest.setSymbol(symbol);
        requestQuoteRequest.setAmount(request.getTransactionAmount());

        if ("D".equalsIgnoreCase(request.getPayByIndicator())) {
            requestQuoteRequest.setDealtCurrency(request.getDebitCurrency());
            requestQuoteRequest.setSide("SELL");
        } else if ("T".equalsIgnoreCase(request.getPayByIndicator())) {
            requestQuoteRequest.setDealtCurrency(request.getTransferCurrency());
            requestQuoteRequest.setSide("BUY");
        }

        return requestQuoteRequest;
    }
}
