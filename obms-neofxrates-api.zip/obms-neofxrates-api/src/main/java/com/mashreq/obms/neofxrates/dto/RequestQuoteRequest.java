package com.mashreq.obms.neofxrates.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

import java.util.Map;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RequestQuoteRequest {
    private String clOrderId;
    private String symbol;
    private Number amount;
    private String dealtCurrency;
    private String side;
    private String rfq;
    private Number expiry;
    private String priceType;
    private String customerAccount;
    private String customerOrg;
    private String nearValueDate;
    private Map<String, Object> customParameters;
}
