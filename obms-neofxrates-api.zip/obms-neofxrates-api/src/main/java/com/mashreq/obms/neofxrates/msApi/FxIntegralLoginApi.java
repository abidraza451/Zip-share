package com.mashreq.obms.neofxrates.msApi;

import com.mashreq.obms.neofxrates.config.ApplicationConfig;
import com.mashreq.obms.neofxrates.dto.LoginRequest;
import com.mashreq.obms.neofxrates.dto.LoginResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
@RequiredArgsConstructor
public class FxIntegralLoginApi {

    private final ApplicationConfig applicationConfig;
    private final RestTemplate restTemplate;

    public ResponseEntity<LoginResponse> login(LoginRequest request) {
        String url = applicationConfig.getBaseUrl() + "/v2/sso/login";

        // RestTemplate's JSON message converter determines Content-Type from the request body.
        // HMAC headers are added by IntegralHmacInterceptor.
        return restTemplate.exchange(
                url, HttpMethod.POST, new HttpEntity<>(request), LoginResponse.class);
    }
}
