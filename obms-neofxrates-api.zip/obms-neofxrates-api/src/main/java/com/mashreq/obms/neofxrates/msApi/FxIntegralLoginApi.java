package com.mashreq.obms.neofxrates.msApi;

import com.mashreq.obms.neofxrates.config.ApplicationConfig;
import com.mashreq.obms.neofxrates.dto.LoginRequest;
import com.mashreq.obms.neofxrates.dto.LoginResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
@RequiredArgsConstructor
public class FxIntegralLoginApi {

    private final ApplicationConfig applicationConfig;
    private final RestTemplate restTemplate;

    public ResponseEntity<LoginResponse> login(LoginRequest request) {
        String url = applicationConfig.getBaseUrl() + "/v2/sso/login";

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);

        return restTemplate.exchange(url, HttpMethod.POST, new HttpEntity<>(request, headers), LoginResponse.class);
    }
}
