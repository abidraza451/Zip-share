package com.mashreq.obms.neofxrates.msApi;

import com.mashreq.obms.neofxrates.config.ApplicationConfig;
import com.mashreq.obms.neofxrates.config.EndpointsConfig;
import com.mashreq.obms.neofxrates.dto.LoginRequest;
import com.mashreq.obms.neofxrates.dto.LoginResponse;
import com.mashreq.obms.neofxrates.hmac.IntegralHmacInterceptor;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
@RequiredArgsConstructor
public class FxIntegralLoginApi {

    private final ApplicationConfig applicationConfig;
    private final EndpointsConfig endpointsConfig;
    private final RestTemplate restTemplate;
    /**
     * HMAC-authenticated login used by the RFQ/indicative flow.
     */
    public ResponseEntity<LoginResponse> login(LoginRequest request) {
        return exchangeLogin(request, false);
    }

    /**
     * Direct Deal login.
     * HMAC is skipped because the SSO token is returned in the response header.
     */
    public ResponseEntity<LoginResponse> loginForDirectDeal(LoginRequest request) {
        return exchangeLogin(request, true);
    }

    private ResponseEntity<LoginResponse> exchangeLogin(LoginRequest request, boolean skipHmac) {
        String url = buildLoginUrl();
        HttpHeaders headers = createHeaders();
        if (skipHmac) {
            headers.set(IntegralHmacInterceptor.SKIP_HMAC_HEADER, Boolean.TRUE.toString());
        }
        HttpEntity<LoginRequest> entity = new HttpEntity<>(request, headers);
        return restTemplate.exchange(url, HttpMethod.POST, entity, LoginResponse.class);
    }

    private String buildLoginUrl() {
        return applicationConfig.getBaseUrl() + endpointsConfig.getSsoLogin();
    }

    private HttpHeaders createHeaders() {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setAccept(java.util.List.of(MediaType.APPLICATION_JSON));
        return headers;
    }
}