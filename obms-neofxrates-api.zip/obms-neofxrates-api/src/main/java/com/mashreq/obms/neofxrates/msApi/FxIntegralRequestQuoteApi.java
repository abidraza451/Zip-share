package com.mashreq.obms.neofxrates.msApi;

import com.mashreq.obms.neofxrates.config.ApplicationConfig;
import com.mashreq.obms.neofxrates.dto.RequestQuoteRequest;
import com.mashreq.obms.neofxrates.dto.RequestQuoteResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
@RequiredArgsConstructor
public class FxIntegralRequestQuoteApi {

    private final ApplicationConfig applicationConfig;
    private final RestTemplate restTemplate;

    /**
     * Matches the Postman RFQ request: POST /v2/rfs with HMAC auth.
     * The supplied Postman Request Quote request does NOT send SSO_TOKEN;
     * session cookies are carried forward from login instead.
     */
    public ResponseEntity<RequestQuoteResponse> requestQuote(RequestQuoteRequest request) {
        String url = applicationConfig.getBaseUrl() + "/v2/rfs";
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);

        return restTemplate.exchange(url, HttpMethod.POST, new HttpEntity<>(request, headers)
                , RequestQuoteResponse.class);
    }
}
