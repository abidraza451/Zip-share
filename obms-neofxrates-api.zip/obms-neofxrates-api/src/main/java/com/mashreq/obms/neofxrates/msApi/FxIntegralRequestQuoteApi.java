package com.mashreq.obms.neofxrates.msApi;

import com.mashreq.obms.neofxrates.config.ApplicationConfig;
import com.mashreq.obms.neofxrates.config.EndpointsConfig;
import com.mashreq.obms.neofxrates.dto.RequestQuoteRequest;
import com.mashreq.obms.neofxrates.dto.RequestQuoteResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
@RequiredArgsConstructor
public class FxIntegralRequestQuoteApi {

    private final ApplicationConfig applicationConfig;
    private final EndpointsConfig  endpointsConfig;
    private final RestTemplate restTemplate;

    /**
     * Matches the Postman RFQ request: POST /v2/rfs with HMAC authentication.
     * RestTemplate determines the JSON Content-Type from the request body.
     * HMAC authentication headers are added by the configured interceptor.
     */
    public ResponseEntity<RequestQuoteResponse> requestQuote(RequestQuoteRequest request) {
        String url = applicationConfig.getBaseUrl() + endpointsConfig.getReqQuote() ;

        return restTemplate.exchange(url, HttpMethod.POST, new HttpEntity<>(request), RequestQuoteResponse.class);
    }
}
