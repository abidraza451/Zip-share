package com.mashreq.obms.neofxrates.dto;

import lombok.Builder;
import lombok.Getter;

import java.math.BigDecimal;
import java.util.Map;

@Getter
@Builder
public class DirectDealBookTradeRequest {

    private String type;
    private String channel;
    private String clientRequestId;
    private String counterparty;
    private String counterpartyAccount;
    private String counterpartyTrader;
    private BigDecimal coverRate;
    private Integer creditMode;
    private String customerOrg;
    private String customerAccount;
    private String trader;
    private BigDecimal dealtAmount;
    private String dealtIns;
    private String note;
    private BigDecimal rate;
    private String rateId;
    private String referenceId;
    private String side;
    private BigDecimal spotRate;
    private Boolean stp;
    private String symbol;
    private String tradeDate;
    private String valueDate;
    private Map<String, String> customParameters;
}
