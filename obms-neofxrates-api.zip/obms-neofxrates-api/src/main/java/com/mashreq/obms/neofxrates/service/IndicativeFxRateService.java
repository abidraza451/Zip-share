package com.mashreq.obms.neofxrates.service;

import com.mashreq.obms.neofxrates.dto.IndicativeFxRateEnquiryRequest;
import com.mashreq.obms.neofxrates.dto.LoginRequest;
import com.mashreq.obms.neofxrates.dto.LoginResponse;
import com.mashreq.obms.neofxrates.dto.RequestQuoteRequest;
import com.mashreq.obms.neofxrates.dto.RequestQuoteResponse;
import com.mashreq.obms.neofxrates.exception.RequestQuoteException;
import com.mashreq.obms.neofxrates.hmac.IntegralHmacProperties;
import com.mashreq.obms.neofxrates.model.IndicativeFxContext;
import com.mashreq.obms.neofxrates.msApi.FxIntegralLoginApi;
import com.mashreq.obms.neofxrates.msApi.FxIntegralQueryQuoteApi;
import com.mashreq.obms.neofxrates.msApi.FxIntegralRequestQuoteApi;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientResponseException;

import java.util.function.Supplier;

@Service
@RequiredArgsConstructor
public class IndicativeFxRateService {

    private final FxIntegralLoginApi loginApi;
    private final FxIntegralRequestQuoteApi requestQuoteApi;
    private final FxIntegralQueryQuoteApi queryQuoteApi;
    private final IntegralHmacProperties hmacProperties;

    public ResponseEntity<String> getcalled(
            IndicativeFxRateEnquiryRequest request) {

        // =========================================================
        // 1. VALIDATION
        // =========================================================

        loginValidate(request);
        validate(request);

        if (request.getClOrderId() == null
                || request.getClOrderId().isBlank()) {

            request.setClOrderId(
                    "RFQ_" + System.currentTimeMillis());
        }

        IndicativeFxContext context =
                new IndicativeFxContext();

        // Postman keeps a session cookie jar between login and RFQ calls.
        // An optional initial cookie string can be supplied when the gateway
        // requires a pre-existing sticky-session cookie.


        context.setClOrderId(request.getClOrderId());

        // =========================================================
        // 2. LOGIN
        // =========================================================

        LoginRequest loginRequest =
                new LoginRequest();

        loginRequest.setUser(
                request.getUser());

        loginRequest.setPass(
                request.getPass());

        loginRequest.setOrg(
                request.getOrg());

        LoginResponse loginResponse =
                call("LOGIN", () -> {

                    ResponseEntity<LoginResponse> response =
                            loginApi.login(loginRequest);

                    if (response == null
                            || response.getBody() == null) {

                        throw new RequestQuoteException(
                                "LOGIN",
                                HttpStatus.BAD_GATEWAY,
                                "Integral returned empty response");
                    }

                    if (!response.getStatusCode()
                            .is2xxSuccessful()) {

                        throw new RequestQuoteException(
                                "LOGIN",
                                response.getStatusCode(),
                                "Integral login failed");
                    }

                    String ssoToken =
                            response.getHeaders()
                                    .getFirst("SSO_TOKEN");

                    if (ssoToken == null
                            || ssoToken.isBlank()) {

                        throw new RequestQuoteException(
                                "LOGIN",
                                HttpStatus.BAD_GATEWAY,
                                "SSO_TOKEN was not returned by Integral");
                    }

                    context.setSsoToken(ssoToken);


                    return response.getBody();
                });

        if (!"OK".equalsIgnoreCase(
                loginResponse.getStatus())) {

            throw new RequestQuoteException(
                    "LOGIN",
                    HttpStatus.BAD_GATEWAY,
                    "Integral login returned unsuccessful response");
        }

        System.out.println("LOGIN successful");

        // =========================================================
        // 3. REQUEST QUOTE
        // =========================================================

        RequestQuoteRequest requestQuoteRequest =
                new RequestQuoteRequest();

        requestQuoteRequest.setClOrderId(
                request.getClOrderId());

        requestQuoteRequest.setSymbol(
                request.getSymbol());

        requestQuoteRequest.setAmount(
                request.getAmount());

        requestQuoteRequest.setDealtCurrency(
                request.getDealtCurrency());

        requestQuoteRequest.setSide(
                request.getSide());

        // Postman sends rfq as the JSON string "true" in the working RFQ request.
        requestQuoteRequest.setRfq(
                Boolean.FALSE.equals(request.getRfq()) ? "false" : "true");

        requestQuoteRequest.setExpiry(
                request.getExpiry() != null ? request.getExpiry() : 120);

        requestQuoteRequest.setPriceType(
                normalizeSpotValue(request.getPriceType(), "Spot"));

        requestQuoteRequest.setCustomerAccount(
                request.getCustomerAccount());

        requestQuoteRequest.setCustomerOrg(
                request.getCustomerOrg());

        requestQuoteRequest.setNearValueDate(
                normalizeSpotValue(request.getNearValueDate(), "Spot"));

        requestQuoteRequest.setCustomParameters(
                request.getCustomParameters());

        call("REQUEST_QUOTE", () -> {

            ResponseEntity<RequestQuoteResponse> response =
                    requestQuoteApi.requestQuote(
                            requestQuoteRequest);



            if (response == null) {

                throw new RequestQuoteException(
                        "REQUEST_QUOTE",
                        HttpStatus.BAD_GATEWAY,
                        "Integral returned empty response");
            }

            if (response.getStatusCode().value() != 202) {

                throw new RequestQuoteException(
                        "REQUEST_QUOTE",
                        response.getStatusCode(),
                        "Request Quote did not return HTTP 202");
            }

            RequestQuoteResponse body =
                    response.getBody();

            if (body == null
                    || body.getRequestId() == null
                    || body.getRequestId().isBlank()) {

                throw new RequestQuoteException(
                        "REQUEST_QUOTE",
                        HttpStatus.BAD_GATEWAY,
                        "Request Quote did not return requestId");
            }

            context.setRequestId(
                    body.getRequestId());

            context.setEvent(
                    body.getEvent());



            return body;
        });

        System.out.println("REQUEST_QUOTE successful");

        System.out.println(
                "Client Order ID: "
                        + context.getClOrderId());

        System.out.println(
                "Request ID: "
                        + context.getRequestId());

        System.out.println(
                "Event: "
                        + context.getEvent());

        // =========================================================
        // 4. WAIT FOR REQUEST QUOTE PROCESSING
        // =========================================================

        try {

            Thread.sleep(20000);

        } catch (InterruptedException ex) {

            Thread.currentThread().interrupt();

            throw new RequestQuoteException(
                    "QUERY_QUOTE",
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "Interrupted while waiting for Query Quote");
        }

        // =========================================================
        // 5. QUERY QUOTE - ONLY ONE CALL
        // =========================================================

        ResponseEntity<String> queryQuoteResponse =
                call("QUERY_QUOTE", () -> {

                    ResponseEntity<String> response =
                            queryQuoteApi.queryByServerId(
                                    context.getRequestId(),
                                    context.getSsoToken());


                    if (response == null) {

                        throw new RequestQuoteException(
                                "QUERY_QUOTE",
                                HttpStatus.BAD_GATEWAY,
                                "Integral returned empty Query Quote response");
                    }

                    if (!response.getStatusCode()
                            .is2xxSuccessful()) {

                        throw new RequestQuoteException(
                                "QUERY_QUOTE",
                                response.getStatusCode(),
                                "Integral Query Quote failed");
                    }

                    if (response.getBody() == null
                            || response.getBody().isBlank()) {

                        throw new RequestQuoteException(
                                "QUERY_QUOTE",
                                HttpStatus.BAD_GATEWAY,
                                "Integral returned empty Query Quote body");
                    }

                    return response;
                });

        System.out.println("QUERY_QUOTE successful");

        System.out.println(
                "Query Quote Response: "
                        + queryQuoteResponse.getBody());

        // =========================================================
        // 6. RETURN COMPLETE QUERY QUOTE RESPONSE
        // =========================================================

        return ResponseEntity
                .status(queryQuoteResponse.getStatusCode())
                .headers(queryQuoteResponse.getHeaders())
                .body(queryQuoteResponse.getBody());
    }

    // =============================================================
    // COMMON API CALL HANDLER
    // =============================================================

    private <T> T call(
            String step,
            Supplier<T> action) {

        try {

            return action.get();

        } catch (RequestQuoteException ex) {

            throw ex;

        } catch (RestClientResponseException ex) {

            throw new RequestQuoteException(
                    step,
                    ex.getStatusCode(),
                    "Integral API returned HTTP "
                            + ex.getStatusCode().value());

        } catch (Exception ex) {

            throw new RequestQuoteException(
                    step,
                    HttpStatus.BAD_GATEWAY,
                    "Unable to call Integral API: "
                            + ex.getMessage());
        }
    }

    // =============================================================
    // LOGIN VALIDATION
    // =============================================================

    private void loginValidate(
            IndicativeFxRateEnquiryRequest request) {

        if (request == null) {

            throw new RequestQuoteException(
                    "VALIDATION",
                    HttpStatus.BAD_REQUEST,
                    "Request body is required");
        }

        require(
                request.getUser(),
                "user");

        require(
                request.getPass(),
                "pass");

        require(
                request.getOrg(),
                "org");
    }

    // =============================================================
    // REQUEST VALIDATION
    // =============================================================

    private void validate(
            IndicativeFxRateEnquiryRequest request) {

        require(
                request.getSymbol(),
                "symbol");

        require(
                request.getDealtCurrency(),
                "dealtCurrency");

        require(
                request.getSide(),
                "side");

        require(
                request.getCustomerAccount(),
                "customerAccount");

        require(
                request.getCustomerOrg(),
                "customerOrg");

        if (!"BUY".equalsIgnoreCase(
                request.getSide())
                && !"SELL".equalsIgnoreCase(
                request.getSide())) {

            throw new RequestQuoteException(
                    "VALIDATION",
                    HttpStatus.BAD_REQUEST,
                    "side must be BUY or SELL");
        }

        if (request.getAmount() == null) {

            throw new RequestQuoteException(
                    "VALIDATION",
                    HttpStatus.BAD_REQUEST,
                    "amount is required");
        }
    }

    private boolean hasText(String value) {
        return value != null && !value.isBlank();
    }

    private String normalizeSpotValue(String value, String defaultValue) {
        if (!hasText(value)) {
            return defaultValue;
        }
        return "SPOT".equalsIgnoreCase(value) ? "Spot" : value;
    }

    // =============================================================
    // REQUIRED FIELD VALIDATION
    // =============================================================

    private void require(
            String value,
            String field) {

        if (value == null
                || value.isBlank()) {

            throw new RequestQuoteException(
                    "VALIDATION",
                    HttpStatus.BAD_REQUEST,
                    field + " is required");
        }
    }
}