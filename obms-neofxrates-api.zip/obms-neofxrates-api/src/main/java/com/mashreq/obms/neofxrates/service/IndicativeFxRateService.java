package com.mashreq.obms.neofxrates.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mashreq.obms.neofxrates.dto.IndicativeFxRateEnquiryRequest;
import com.mashreq.obms.neofxrates.dto.LoginRequest;
import com.mashreq.obms.neofxrates.dto.LoginResponse;
import com.mashreq.obms.neofxrates.dto.QueryQuoteRequestBody;
import com.mashreq.obms.neofxrates.dto.RequestQuoteRequest;
import com.mashreq.obms.neofxrates.dto.RequestQuoteResponse;
import com.mashreq.obms.neofxrates.dto.TsdFxRateEnquiryResponse;
import com.mashreq.obms.neofxrates.entity.TraditionalCurrencyPairDirection;
import com.mashreq.obms.neofxrates.exception.RequestQuoteException;
import com.mashreq.obms.neofxrates.model.IndicativeFxContext;
import com.mashreq.obms.neofxrates.msApi.FxIntegralLoginApi;
import com.mashreq.obms.neofxrates.msApi.FxIntegralQueryQuoteApi;
import com.mashreq.obms.neofxrates.msApi.FxIntegralRequestQuoteApi;
import com.mashreq.obms.neofxrates.repository.TraditionalCurrencyPairDirectionRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientResponseException;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;

@Service
@RequiredArgsConstructor
public class IndicativeFxRateService {

    private final FxIntegralLoginApi loginApi;
    private final FxIntegralRequestQuoteApi requestQuoteApi;
    private final FxIntegralQueryQuoteApi queryQuoteApi;
    private final TraditionalCurrencyPairDirectionRepository currencyPairRepository;
    private final ObjectMapper objectMapper;

    public ResponseEntity<TsdFxRateEnquiryResponse> fetchFxRate(IndicativeFxRateEnquiryRequest request) {

        loginValidate(request);
        validate(request);

        if (request.getRefNo() == null || request.getRefNo().isBlank()) {
            request.setRefNo("RFQ_" + System.currentTimeMillis());
        }

        // Resolve the configured Integral symbol before making any outbound call.
        // The database always stores the strong/base currency first and the
        // weak/quote currency second.
        TraditionalCurrencyPairDirection pair = resolveCurrencyPair(request);
        String symbol = pair.getBaseCurrency() + "/" + pair.getQuoteCurrency();

        IndicativeFxContext context = new IndicativeFxContext();
        context.setClOrderId(request.getRefNo());

        // LOGIN
        LoginRequest loginRequest = new LoginRequest();
        loginRequest.setUser(request.getUser());
        loginRequest.setPass(request.getPass());
        loginRequest.setOrg(request.getOrg());

        LoginResponse loginResponse = call("LOGIN", () -> {
            ResponseEntity<LoginResponse> response = loginApi.login(loginRequest);
            if (response == null || response.getBody() == null) {
                throw new RequestQuoteException("LOGIN", HttpStatus.BAD_GATEWAY,
                        "Integral returned empty response");
            }
            if (!response.getStatusCode().is2xxSuccessful()) {
                throw new RequestQuoteException("LOGIN", response.getStatusCode(),
                        "Integral login failed");
            }
            return response.getBody();
        });

        if (!"OK".equalsIgnoreCase(loginResponse.getStatus())) {
            throw new RequestQuoteException("LOGIN", HttpStatus.BAD_GATEWAY,
                    "Integral login returned unsuccessful response");
        }

        // REQUEST QUOTE - symbol comes from the database, not a hard-coded value.
        RequestQuoteRequest requestQuoteRequest =
                new RequestQuoteRequest().calculate(request, symbol);

        call("REQUEST_QUOTE", () -> {
            ResponseEntity<RequestQuoteResponse> response =
                    requestQuoteApi.requestQuote(requestQuoteRequest);

            if (response == null) {
                throw new RequestQuoteException("REQUEST_QUOTE", HttpStatus.BAD_GATEWAY,
                        "Integral returned empty response");
            }
            if (response.getStatusCode().value() != 202) {
                throw new RequestQuoteException("REQUEST_QUOTE", response.getStatusCode(),
                        "Request Quote did not return HTTP 202");
            }

            RequestQuoteResponse body = response.getBody();
            if (body == null || body.getRequestId() == null || body.getRequestId().isBlank()) {
                throw new RequestQuoteException("REQUEST_QUOTE", HttpStatus.BAD_GATEWAY,
                        "Request Quote did not return requestId");
            }

            context.setRequestId(body.getRequestId());
            context.setEvent(body.getEvent());
            return body;
        });

        // Integral needs a short processing window before Query Quote.
        try {
            Thread.sleep(2000);
        } catch (InterruptedException ex) {
            Thread.currentThread().interrupt();
            throw new RequestQuoteException("QUERY_QUOTE", HttpStatus.INTERNAL_SERVER_ERROR,
                    "Interrupted while waiting for Query Quote");
        }

        // QUERY QUOTE - exactly one call.
        ResponseEntity<String> queryQuoteResponse = call("QUERY_QUOTE", () -> {
            ResponseEntity<String> response =
                    queryQuoteApi.queryByServerId(context.getRequestId());
            if (response == null) {
                throw new RequestQuoteException("QUERY_QUOTE", HttpStatus.BAD_GATEWAY,
                        "Integral returned empty Query Quote response");
            }
            if (!response.getStatusCode().is2xxSuccessful()) {
                throw new RequestQuoteException("QUERY_QUOTE", response.getStatusCode(),
                        "Integral Query Quote failed");
            }
            if (response.getBody() == null || response.getBody().isBlank()) {
                throw new RequestQuoteException("QUERY_QUOTE", HttpStatus.BAD_GATEWAY,
                        "Integral returned empty Query Quote body");
            }
            return response;
        });

        TsdFxRateEnquiryResponse tsdResponse = buildTsdResponse(
                queryQuoteResponse.getBody(), request, requestQuoteRequest);

        return ResponseEntity.status(queryQuoteResponse.getStatusCode()).body(tsdResponse);
    }

    private TraditionalCurrencyPairDirection resolveCurrencyPair(
            IndicativeFxRateEnquiryRequest request) {

        String debitCurrency = normalizeCurrency(request.getDebitCurrency());
        String transferCurrency = normalizeCurrency(request.getTransferCurrency());

        // First try the request direction. If found, Integral receives BASE/QUOTE
        // exactly as stored in the database.
        return currencyPairRepository
                .findByBaseCurrencyAndQuoteCurrency(debitCurrency, transferCurrency)
                .orElseGet(() -> currencyPairRepository
                        .findByBaseCurrencyAndQuoteCurrency(transferCurrency, debitCurrency)
                        .orElseThrow(() -> new RequestQuoteException(
                                "CURRENCY_PAIR",
                                HttpStatus.BAD_REQUEST,
                                "No currency pair configured for "
                                        + debitCurrency + "/" + transferCurrency)));
    }

    private TsdFxRateEnquiryResponse buildTsdResponse(
            String integralResponse,
            IndicativeFxRateEnquiryRequest request,
            RequestQuoteRequest requestQuoteRequest) {

        try {
            Map<String, Object> integralRoot = objectMapper.readValue(
                    integralResponse,
                    new TypeReference<Map<String, Object>>() {
                    });

            if (integralRoot == null || integralRoot.isEmpty()) {
                throw new RequestQuoteException("QUERY_QUOTE", HttpStatus.BAD_GATEWAY,
                        "Integral Query Quote response is empty");
            }

            Object upstreamData = integralRoot.get("data");
            Map<String, Object> data;
            if (upstreamData instanceof Map<?, ?>) {
                data = toStringObjectMap((Map<?, ?>) upstreamData);
            } else {
                data = new LinkedHashMap<>(integralRoot);
            }

            if (integralRoot.containsKey("cachedRate")) {
                data.put("cachedRate", integralRoot.get("cachedRate"));
            } else {
                data.putIfAbsent("cachedRate", null);
            }

            data.put("side", requestQuoteRequest.getSide());
            data.put("rfq", requestQuoteRequest.getRfq());

            // Integral only accepts the configured BASE/QUOTE direction. Therefore:
            // Base = dealt currency -> Normal -> N
            // Quote = dealt currency -> Inverse -> Y
            String inverse = isInverse(requestQuoteRequest.getDealtCurrency(),
                    requestQuoteRequest.getSymbol()) ? "Y" : "N";
            data.put("inverse", inverse);

            calculateReciprocalRateAndSettledAmount(data, inverse);

            TsdFxRateEnquiryResponse response = new TsdFxRateEnquiryResponse();
            response.setData(data);
            response.setRequestBody(QueryQuoteRequestBody.from(request));
            return response;
        } catch (RequestQuoteException ex) {
            throw ex;
        } catch (Exception ex) {
            throw new RequestQuoteException("QUERY_QUOTE", HttpStatus.BAD_GATEWAY,
                    "Unable to parse Integral Query Quote response: " + ex.getMessage());
        }
    }

    private boolean isInverse(String dealtCurrency, String symbol) {
        if (dealtCurrency == null || symbol == null || !symbol.contains("/")) {
            throw new RequestQuoteException("QUERY_QUOTE", HttpStatus.BAD_GATEWAY,
                    "Unable to determine inverse direction");
        }

        String[] currencies = symbol.split("/", -1);
        String baseCurrency = normalizeCurrency(currencies[0]);
        String quoteCurrency = normalizeCurrency(currencies[1]);
        String normalizedDealt = normalizeCurrency(dealtCurrency);

        if (baseCurrency.equals(normalizedDealt)) {
            return false;
        }
        if (quoteCurrency.equals(normalizedDealt)) {
            return true;
        }

        throw new RequestQuoteException("QUERY_QUOTE", HttpStatus.BAD_GATEWAY,
                "Dealt currency " + normalizedDealt
                        + " is not part of currency pair " + symbol);
    }

    /**
     * Calculates TSD reciprocalRate and replaces each Integral settledAmount
     * using the documented normal/inverse formula.
     *
     * Normal (inverse=N): settledAmount = dealtAmount * rate
     * Inverse (inverse=Y): settledAmount = dealtAmount / rate
     * reciprocalRate = 1 / rate
     */
    private void calculateReciprocalRateAndSettledAmount(
            Map<String, Object> data, String inverse) {

        Object quotesObject = data.get("quotes");
        if (!(quotesObject instanceof List<?> quotes)) {
            data.put("reciprocalRate", null);
            return;
        }

        BigDecimal firstRate = null;

        for (int quoteIndex = 0; quoteIndex < quotes.size(); quoteIndex++) {
            Object quoteObject = quotes.get(quoteIndex);
            if (!(quoteObject instanceof Map<?, ?> quoteMapRaw)) {
                continue;
            }

            Map<String, Object> quoteMap = toStringObjectMap(quoteMapRaw);
            Object offersObject = quoteMap.get("offers");
            if (!(offersObject instanceof List<?> offers)) {
                continue;
            }

            List<Object> updatedOffers = new java.util.ArrayList<>();

            for (Object offerObject : offers) {
                if (!(offerObject instanceof Map<?, ?> offerMapRaw)) {
                    updatedOffers.add(offerObject);
                    continue;
                }

                Map<String, Object> offerMap = toStringObjectMap(offerMapRaw);
                BigDecimal rate = toBigDecimal(offerMap.get("rate"));
                BigDecimal dealtAmount = toBigDecimal(offerMap.get("dealtAmount"));

                if (rate == null || rate.compareTo(BigDecimal.ZERO) <= 0) {
                    throw new RequestQuoteException("QUERY_QUOTE", HttpStatus.BAD_GATEWAY,
                            "Integral quote contains missing or invalid rate");
                }

                if (firstRate == null) {
                    firstRate = rate;
                }

                if (dealtAmount != null) {
                    BigDecimal settledAmount;
                    if ("Y".equals(inverse)) {
                        settledAmount = dealtAmount.divide(rate, 10, RoundingMode.HALF_UP);
                    } else {
                        settledAmount = dealtAmount.multiply(rate);
                    }
                    offerMap.put("settledAmount", normalizeNumber(settledAmount));
                }

                updatedOffers.add(offerMap);
            }

            quoteMap.put("offers", updatedOffers);
            @SuppressWarnings("unchecked")
            List<Object> mutableQuotes = (List<Object>) quotes;
            mutableQuotes.set(quoteIndex, quoteMap);
        }

        data.put("reciprocalRate",
                firstRate == null ? null : normalizeNumber(
                        BigDecimal.ONE.divide(firstRate, 10, RoundingMode.HALF_UP)));
    }

    private BigDecimal toBigDecimal(Object value) {
        if (value == null) {
            return null;
        }
        if (value instanceof BigDecimal decimal) {
            return decimal;
        }
        if (value instanceof Number number) {
            return BigDecimal.valueOf(number.doubleValue());
        }
        if (value instanceof String string && !string.isBlank()) {
            try {
                return new BigDecimal(string.trim());
            } catch (NumberFormatException ex) {
                return null;
            }
        }
        return null;
    }

    private Number normalizeNumber(BigDecimal value) {
        BigDecimal normalized = value.stripTrailingZeros();
        if (normalized.scale() < 0) {
            normalized = normalized.setScale(0);
        }
        return normalized;
    }

    private Map<String, Object> toStringObjectMap(Map<?, ?> source) {
        Map<String, Object> result = new LinkedHashMap<>();
        source.forEach((key, value) -> result.put(String.valueOf(key), value));
        return result;
    }

    private <T> T call(String step, Supplier<T> action) {
        try {
            return action.get();
        } catch (RequestQuoteException ex) {
            throw ex;
        } catch (RestClientResponseException ex) {
            throw new RequestQuoteException(step, ex.getStatusCode(),
                    "Integral API returned HTTP " + ex.getStatusCode().value());
        } catch (Exception ex) {
            throw new RequestQuoteException(step, HttpStatus.BAD_GATEWAY,
                    "Unable to call Integral API: " + ex.getMessage());
        }
    }

    private void loginValidate(IndicativeFxRateEnquiryRequest request) {
        if (request == null) {
            throw new RequestQuoteException("VALIDATION", HttpStatus.BAD_REQUEST,
                    "Request body is required");
        }
        require(request.getUser(), "user");
        require(request.getPass(), "pass");
        require(request.getOrg(), "org");
    }

    private void validate(IndicativeFxRateEnquiryRequest request) {
        require(request.getDebitCurrency(), "debitCurrency");
        require(request.getTransferCurrency(), "transferCurrency");
        require(request.getPayByIndicator(), "payByIndicator");
        if (!"D".equalsIgnoreCase(request.getPayByIndicator())
                && !"T".equalsIgnoreCase(request.getPayByIndicator())) {
            throw new RequestQuoteException("VALIDATION", HttpStatus.BAD_REQUEST,
                    "payByIndicator must be D or T");
        }
        if (request.getTransactionAmount() == null) {
            throw new RequestQuoteException("VALIDATION", HttpStatus.BAD_REQUEST,
                    "transactionAmount is required");
        }
    }

    private void require(String value, String field) {
        if (value == null || value.isBlank()) {
            throw new RequestQuoteException("VALIDATION", HttpStatus.BAD_REQUEST,
                    field + " is required");
        }
    }

    private String normalizeCurrency(String currency) {
        return currency.trim().toUpperCase();
    }
}
