package com.mashreq.obms.neofxrates.dto;

import lombok.Data;

import java.util.Map;

@Data
public class IndicativeFxRateEnquiryRequest {

    //login
    private String user;
    private String pass;
    private String org;

    //request qoute
    private String clOrderId;
    private String symbol;
    private Number amount;
    private String dealtCurrency;
    private String side;
    private Boolean rfq = true;
    private Number expiry = 30;
    private String priceType = "Spot";
    private String customerAccount;
    private String customerOrg;
    private String nearValueDate = "SPOT";
    private Map<String, Object> customParameters;

}
