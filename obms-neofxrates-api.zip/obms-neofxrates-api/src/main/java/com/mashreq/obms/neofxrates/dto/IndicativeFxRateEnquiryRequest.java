package com.mashreq.obms.neofxrates.dto;

import lombok.Data;

import java.time.LocalDate;
import java.util.Date;


@Data
public class IndicativeFxRateEnquiryRequest {

    //login
    private String user;
    private String pass;
    private String org;

    private String debitCurrency;
    private String transferCurrency;
    private String payByIndicator;
    private Number transactionAmount;
    private LocalDate transactionDate = LocalDate.now();
    private String cif;
    private String refNo;
    private String source;







}
