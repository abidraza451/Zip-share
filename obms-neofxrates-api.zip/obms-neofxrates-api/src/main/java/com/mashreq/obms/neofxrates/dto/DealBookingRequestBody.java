package com.mashreq.obms.neofxrates.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Request fields exposed back to the caller as part of the Deal Booking
 * response. Fields already returned by Integral in {@code data} are
 * intentionally excluded to avoid duplicating the response contract.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class DealBookingRequestBody {

    private String cif;
    private String quoteId;
    private String refNo;
    private Boolean rfq;
    private String side;
    private String source;
}
