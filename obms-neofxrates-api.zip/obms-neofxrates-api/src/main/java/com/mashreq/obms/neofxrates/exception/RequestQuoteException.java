package com.mashreq.obms.neofxrates.exception;

import lombok.Getter;
import org.springframework.http.HttpStatusCode;
@Getter
public class RequestQuoteException extends RuntimeException {

    private final String step;
    private final HttpStatusCode statusCode;

    public RequestQuoteException(String step, HttpStatusCode statusCode, String message) {
        super(message);
        this.step = step;
        this.statusCode = statusCode;
    }


}
