package com.mashreq.obms.neofxrates.msApi;

import com.mashreq.obms.neofxrates.config.ApplicationConfig;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
@RequiredArgsConstructor
public class FxIntegralQueryQuoteApi {

    private final ApplicationConfig applicationConfig;
    private final RestTemplate restTemplate;

    /**
     * Query Quote using Client Order ID.
     */
    public ResponseEntity<String> queryByClientId(String clOrderId, String ssoToken, String cookieHeader) {

        String url = applicationConfig.getBaseUrl() + "/v2/rfs?clOrderId=" + clOrderId;
        HttpHeaders headers = buildHeaders(ssoToken);
        return restTemplate.exchange(url, HttpMethod.GET, new HttpEntity<>(headers), String.class);
    }

    /**
     * Query Quote using the exact server request ID returned by Request Quote.
     * Matches the Postman workflow: GET /v2/rfs/{requestId}.
     */
    public ResponseEntity<String> queryByServerId(String requestId, String ssoToken) {

        String url = applicationConfig.getBaseUrl() + "/v2/rfs/" + requestId;

        HttpHeaders headers = buildHeaders(ssoToken);
        return restTemplate.exchange(url, HttpMethod.GET, new HttpEntity<>(headers), String.class);
    }

    private HttpHeaders buildHeaders(String ssoToken) {
        HttpHeaders headers = new HttpHeaders();
        headers.set("SSO_TOKEN", ssoToken);
        return headers;
    }
}
