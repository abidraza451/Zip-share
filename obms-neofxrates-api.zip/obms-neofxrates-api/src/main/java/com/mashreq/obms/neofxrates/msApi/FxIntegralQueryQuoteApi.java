package com.mashreq.obms.neofxrates.msApi;

import com.mashreq.obms.neofxrates.config.ApplicationConfig;
import com.mashreq.obms.neofxrates.config.EndpointsConfig;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
@RequiredArgsConstructor
public class FxIntegralQueryQuoteApi {

    private final ApplicationConfig applicationConfig;
    private final RestTemplate restTemplate;
    private final EndpointsConfig endpointsConfig;

    /**
     * Query Quote using Client Order ID.
     */
    public ResponseEntity<String> queryByClientId(String clOrderId) {
        String url = applicationConfig.getBaseUrl() + endpointsConfig.getQueryByClientId()  + clOrderId;
        return restTemplate.exchange(url, HttpMethod.GET, HttpEntity.EMPTY, String.class);
    }
    /**
     * Query Quote using the exact server request ID returned by Request Quote.
     * Matches the Postman workflow: GET /v2/rfs/{requestId}.
     */
    public ResponseEntity<String> queryByServerId(String requestId) {
        String url = applicationConfig.getBaseUrl() + endpointsConfig.getQueryByServerId()  + requestId;
        return restTemplate.exchange(url, HttpMethod.GET, HttpEntity.EMPTY, String.class);
    }
}
