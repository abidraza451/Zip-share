package com.mashreq.obms.neofxrates.msApi;

import com.mashreq.obms.neofxrates.config.ApplicationConfig;
import com.mashreq.obms.neofxrates.hmac.IntegralHmacInterceptor;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
@RequiredArgsConstructor
public class FxIntegralQueryOrderApi {

    private final ApplicationConfig applicationConfig;
    private final RestTemplate restTemplate;

    /** Existing HMAC-authenticated Query Order call. */
    public ResponseEntity<String> queryOrder(String orderId) {
        return exchange(orderId, null);
    }

    /** Direct Deal Query Order using the SSO_TOKEN returned by Direct Deal login. */
    public ResponseEntity<String> queryOrderWithSso(
            String orderId,
            String ssoToken) {
        return exchange(orderId, ssoToken);
    }

    private ResponseEntity<String> exchange(String orderId, String ssoToken) {
        String url = applicationConfig.getBaseUrl() + "/v2/orders/" + orderId;

        HttpHeaders headers = new HttpHeaders();
        if (ssoToken != null && !ssoToken.isBlank()) {
            headers.set("SSO_TOKEN", ssoToken);
            headers.set(IntegralHmacInterceptor.SKIP_HMAC_HEADER, "true");
        }

        return restTemplate.exchange(
                url,
                HttpMethod.GET,
                new HttpEntity<>(headers),
                String.class);
    }
}
