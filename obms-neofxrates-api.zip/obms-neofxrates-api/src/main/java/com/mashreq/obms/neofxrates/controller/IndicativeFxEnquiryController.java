package com.mashreq.obms.neofxrates.controller;

import com.mashreq.obms.neofxrates.dto.IndicativeFxRateEnquiryRequest;
import com.mashreq.obms.neofxrates.service.IndicativeFxRateService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/")
@RequiredArgsConstructor
public class IndicativeFxEnquiryController {

    private final IndicativeFxRateService indicativeFxRateService;

    @PostMapping("/indicativeFxRateEnquiry")
    public ResponseEntity<String> acceptQuote(
            @RequestBody IndicativeFxRateEnquiryRequest request) {

        return indicativeFxRateService.getcalled(request);
    }
}