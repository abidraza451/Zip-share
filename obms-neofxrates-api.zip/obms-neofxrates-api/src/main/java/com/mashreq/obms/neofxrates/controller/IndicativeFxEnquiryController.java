package com.mashreq.obms.neofxrates.controller;

import com.mashreq.obms.neofxrates.dto.IndicativeFxRateEnquiryRequest;
import com.mashreq.obms.neofxrates.dto.TsdFxRateEnquiryResponse;
import com.mashreq.obms.neofxrates.service.IndicativeFxRateService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/indicative")
@RequiredArgsConstructor
public class IndicativeFxEnquiryController {

    private final IndicativeFxRateService indicativeFxRateService;

    @PostMapping("/fxRateEnquiry")
    public ResponseEntity<TsdFxRateEnquiryResponse> acceptQuote(
            @RequestBody IndicativeFxRateEnquiryRequest request) {

        return indicativeFxRateService.fetchFxRate(request);
    }
}