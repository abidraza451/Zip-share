package com.mashreq.obms.neofxrates.msApi;

import com.mashreq.obms.neofxrates.config.ApplicationConfig;
import com.mashreq.obms.neofxrates.config.EndpointsConfig;
import com.mashreq.obms.neofxrates.dto.AcceptQuoteRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
@RequiredArgsConstructor
public class FxIntegralAcceptQuoteApi {

    private final ApplicationConfig applicationConfig;
    private final EndpointsConfig endpointsConfig;
    private final RestTemplate restTemplate;

    /**
     * Matches Postman Step 3 - Accept Quote:
     * POST /v2/rfs/{requestId}
     *
     * Integral may return a successful status with an empty response body.
     * Therefore the response is deliberately read as String rather than a
     * response DTO and callers must validate the HTTP status, not the body.
     */
    public ResponseEntity<String> acceptQuote(String requestId, AcceptQuoteRequest request) {
        String url = applicationConfig.getBaseUrl() + endpointsConfig.getAcceptQuote() + requestId;
        return restTemplate.exchange(
                url,
                HttpMethod.POST,
                new HttpEntity<>(request),
                String.class);
    }
}
