package com.mashreq.obms.neofxrates.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mashreq.obms.neofxrates.config.DirectDealLoginProperties;
import com.mashreq.obms.neofxrates.config.EndpointsConfig;
import com.mashreq.obms.neofxrates.dto.*;
import com.mashreq.obms.neofxrates.exception.RequestQuoteException;
import com.mashreq.obms.neofxrates.msApi.FxIntegralBookTradeApi;
import com.mashreq.obms.neofxrates.msApi.FxIntegralLoginApi;
import com.mashreq.obms.neofxrates.msApi.FxIntegralPlaceOrderApi;
import com.mashreq.obms.neofxrates.msApi.FxIntegralQueryOrderApi;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientResponseException;

import java.math.BigDecimal;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class DirectDealService {

    private final FxIntegralLoginApi loginApi;
    private final FxIntegralPlaceOrderApi placeOrderApi;
    private final FxIntegralQueryOrderApi queryOrderApi;
    private final FxIntegralBookTradeApi bookTradeApi;
    private final DirectDealLoginProperties loginProperties;
    private final ObjectMapper objectMapper;
    private final EndpointsConfig endpointsConfig;

    /**
     * Executes the Direct Deal workflow exactly in the same logical order as
     * the Postman Reversals Workflow:
     *
     * 1. LOGIN
     * 2. PLACE ORDER (AtBest)
     * 3. QUERY ORDER using the orderId returned by PLACE ORDER (single call)
     * 4. BOOK TRADE after QUERY ORDER
     *
     * The incoming DirectDealRequest contract is kept unchanged. Values that
     * Postman generates in pre-request scripts (clientOrderId, T+2 value date,
     * reversal clientRequestId and today's trade date) are generated here.
     *
     * Direct Deal uses the Integral SSO_TOKEN returned by LOGIN for all
     * subsequent Direct Deal calls. This SSO flow is isolated to Direct Deal;
     * other APIs in the application continue using their existing authentication.
     */
    public ResponseEntity<DirectDealResponse> directDeal(DirectDealRequest request) {
        reqValidate(request);

        String clientOrderId = generateClientOrderId();
        String reversalValueDate = calculateTPlusTwoBusinessDays();

        // 1. LOGIN
        String ssoToken = login(request);

        // 2. PLACE ORDER
        DirectDealOrderResponse placedOrder = placeOrder(request, clientOrderId, reversalValueDate, ssoToken);
        // 3. QUERY ORDER
        // Exactly one Query Order call, using the orderId returned by Place Order.
        // No polling/retry is performed for Direct Deal.
        DirectDealOrderResponse queriedOrder = queryOrder(placedOrder.getOrderId(), ssoToken);
        // Query Order is the final lookup step before Book Trade.
        // Do not require the status to be FILLED here. Integral may return
        // NEW/RECEIVED at this point, and the requested Direct Deal workflow
        // must continue to Book Trade after the single Query Order call.

        // 4. BOOK TRADE
        ResponseEntity<String> bookTradeResponse = bookTrade(request, queriedOrder, reversalValueDate, ssoToken);

        return buildDirectDealResponse(request, bookTradeResponse);
    }

    /**
     * Builds the public Direct Deal response without changing the Integral
     * Book Trade contract. The Book Trade payload is exposed under {@code data}
     * and the incoming request is exposed under {@code requestBody}. Any
     * top-level request field that is also present in the Book Trade response
     * is removed from requestBody to avoid duplicate data.
     */
    private ResponseEntity<DirectDealResponse> buildDirectDealResponse(DirectDealRequest request,
            ResponseEntity<String> bookTradeResponse) {
        try {
            DirectDealBookTradeResponse data = objectMapper.readValue(bookTradeResponse.getBody(),
                    DirectDealBookTradeResponse.class);

            Map<String, Object> requestBody = objectMapper.convertValue(request, new TypeReference<Map<String, Object>>() {});

            // Remove only fields whose names are already represented by the
            // Book Trade response. Using a plain Map here is intentional: it
            // prevents Jackson from serializing JsonNode/ObjectNode internals
            // such as nodeType, containerNode, textual, etc.
            data.getResponseFieldNames().forEach(requestBody::remove);
            DirectDealResponse response = new DirectDealResponse();
            response.setData(data);
            response.setRequestBody(requestBody);

            return ResponseEntity.status(bookTradeResponse.getStatusCode())
                    .headers(bookTradeResponse.getHeaders())
                    .body(response);
        } catch (Exception ex) {
            throw new RequestQuoteException("BOOK_TRADE", HttpStatus.BAD_GATEWAY, "Unable to parse Integral Book Trade response: " + ex.getMessage());
        }
    }

    private String login(DirectDealRequest request) {
        LoginRequest loginRequest = new LoginRequest();
        loginRequest.setUser(isBlank(request.getUser()) ? loginProperties.getUser() : request.getUser());
        loginRequest.setPass(isBlank(request.getPass()) ? loginProperties.getPass() : request.getPass());
        loginRequest.setOrg(isBlank(request.getOrg()) ? loginProperties.getOrg() : request.getOrg());

        require(loginRequest.getUser(), "app.direct-deal.login.user");
        require(loginRequest.getPass(), "app.direct-deal.login.pass");
        require(loginRequest.getOrg(), "app.direct-deal.login.org");
        try {
            ResponseEntity<LoginResponse> response = loginApi.loginForDirectDeal(loginRequest);
            if (response == null) {throw new RequestQuoteException("LOGIN", HttpStatus.BAD_GATEWAY, "Integral returned empty Login response");
            }
            if (!response.getStatusCode().is2xxSuccessful()) {throw new RequestQuoteException(
                    "LOGIN", response.getStatusCode(), "Integral Login failed");
            }

            String ssoToken = response.getHeaders().getFirst("SSO_TOKEN");
            if (isBlank(ssoToken)) {throw new RequestQuoteException("LOGIN",
                        HttpStatus.BAD_GATEWAY, "Integral Login succeeded but SSO_TOKEN was not returned in the response header");
            }
            LoginResponse body = response.getBody();
            if (body != null && body.getStatus() != null && !"OK".equalsIgnoreCase(body.getStatus()) && !"SUCCESS".equalsIgnoreCase(body.getStatus())) {
                throw new RequestQuoteException("LOGIN", HttpStatus.BAD_GATEWAY, "Integral Login returned unsuccessful status: " + body.getStatus());
            }
            return ssoToken;
        } catch (RequestQuoteException ex) {
            throw ex;
        } catch (RestClientResponseException ex) {
            throw new RequestQuoteException("LOGIN", ex.getStatusCode(), buildIntegralErrorMessage("Login",
                    ex.getStatusCode().value(),
                    ex.getResponseBodyAsString()));
        } catch (Exception ex) {
            throw new RequestQuoteException("LOGIN", HttpStatus.BAD_GATEWAY, "Unable to call Integral Login: " + ex.getMessage());
        }
    }

    private DirectDealOrderResponse placeOrder(
            DirectDealRequest request,
            String clientOrderId,
            String reversalValueDate,
            String ssoToken) {

        // Exact Postman equivalent:
        // var timestamp = new Date().getTime();
        // pm.collectionVariables.set('clientOrderId', timestamp);
        DirectDealPlaceOrderRequest orderRequest =
                DirectDealPlaceOrderRequest.builder()
                        .coId(clientOrderId)
                        .type("AtBest")
                        .symbol(request.getSymbol())
                        .side(toTitleCaseSide(request.getSide()))
                        .size(request.getSize())
                        .currency(request.getCurrency())
                        .timeInForce("FOK")
                        .valueDate(reversalValueDate)
                        .org(isBlank(request.getOrg()) ? "NEOFX" : request.getOrg())
                        .account(isBlank(request.getAccount()) ? "NEOFX" : request.getAccount())
                        .customParameters(toOrderCustomParameters(request))
                        .build();

        try {
            ResponseEntity<String> response = placeOrderApi.placeOrderWithSso(orderRequest, ssoToken);
            if (response == null) {
                throw new RequestQuoteException("PLACE_ORDER",
                        HttpStatus.BAD_GATEWAY, "Integral Place Order returned an empty response");
            }
            validateSuccessfulResponse(response, "PLACE_ORDER");
            if (response.getBody() == null || response.getBody().isBlank()) {
                throw new RequestQuoteException("PLACE_ORDER",
                        HttpStatus.BAD_GATEWAY, "Integral Place Order returned an empty response body");
            }
            DirectDealOrderResponse order = objectMapper.readValue(
                    response.getBody(), DirectDealOrderResponse.class);

            require(order.getOrderId(), "Integral Place Order response orderId");

            // Postman explicitly verifies that the server echoed the newly
            // generated clientOrderId. Doing the same prevents us from querying
            // a stale/different order in the next step.
            if (!clientOrderId.equals(String.valueOf(order.getCoId()))) {
                throw new RequestQuoteException("PLACE_ORDER", HttpStatus.BAD_GATEWAY,
                        "Integral Place Order returned coId " + order.getCoId()
                                + " but expected generated coId " + clientOrderId);
            }
            return order;
        } catch (RequestQuoteException ex) {
            System.out.println("[DIRECT-DEAL] STEP 2/4 - PLACE ORDER - FAILED: "
                    + ex.getMessage());
            throw ex;
        } catch (RestClientResponseException ex) {
            System.out.println("[DIRECT-DEAL] STEP 2/4 - PLACE ORDER - FAILED HTTP "
                    + ex.getStatusCode().value());
            System.out.println("[DIRECT-DEAL] PLACE ORDER error response: "
                    + ex.getResponseBodyAsString());
            throw new RequestQuoteException("PLACE_ORDER",
                    ex.getStatusCode(), buildIntegralErrorMessage(
                            "Place Order", ex.getStatusCode().value(),
                            ex.getResponseBodyAsString()));
        } catch (Exception ex) {
            System.out.println("[DIRECT-DEAL] STEP 2/4 - PLACE ORDER - FAILED: " + ex.getMessage());
            throw new RequestQuoteException(
                    "PLACE_ORDER", HttpStatus.BAD_GATEWAY,
                    "Unable to parse Integral Place Order response: " + ex.getMessage());
        }
    }

    private DirectDealOrderResponse queryOrder(String orderId, String ssoToken) {
        try {
            // IMPORTANT: Postman Query Order uses the orderId returned by the
            // Place Order response. It does NOT use clientOrderId/coId.
            String urlDescription = endpointsConfig.getQueryOrder() + orderId;
            System.out.println("[DIRECT-DEAL] Calling Integral QUERY ORDER: " + urlDescription);

            ResponseEntity<String> response = queryOrderApi.queryOrderWithSso(orderId, ssoToken);

            if (response == null) {
                throw new RequestQuoteException(
                        "QUERY_ORDER", HttpStatus.BAD_GATEWAY,
                        "Integral Query Order returned an empty response");
            }

            validateSuccessfulResponse(response, "QUERY_ORDER");

            if (response.getBody() == null || response.getBody().isBlank()) {
                throw new RequestQuoteException(
                        "QUERY_ORDER",
                        HttpStatus.BAD_GATEWAY,
                        "Integral Query Order returned an empty response body");
            }

            String body = response.getBody().trim();

            // Postman documents Query Order as an array. Accepting an object as
            // well is harmless and keeps the integration tolerant to UAT format
            // differences.
            if (body.startsWith("[")) {
                List<DirectDealOrderResponse> orders = objectMapper.readValue(
                        body, new TypeReference<List<DirectDealOrderResponse>>() {});

                if (orders == null || orders.isEmpty() || orders.get(0) == null) {
                    throw new RequestQuoteException(
                            "QUERY_ORDER", HttpStatus.BAD_GATEWAY,
                            "Integral Query Order returned no order data");
                }

                return orders.get(0);
            }

            return objectMapper.readValue(body, DirectDealOrderResponse.class);
        } catch (RequestQuoteException ex) {
            System.out.println("[DIRECT-DEAL] QUERY ORDER - FAILED: " + ex.getMessage());
            throw ex;
        } catch (RestClientResponseException ex) {
            System.out.println("[DIRECT-DEAL] QUERY ORDER - FAILED HTTP " + ex.getStatusCode().value());
            System.out.println("[DIRECT-DEAL] QUERY ORDER error response: " + ex.getResponseBodyAsString());
            throw new RequestQuoteException(
                    "QUERY_ORDER",
                    ex.getStatusCode(),
                    buildIntegralErrorMessage("Query Order", ex.getStatusCode().value(),
                            ex.getResponseBodyAsString()));
        } catch (Exception ex) {
            System.out.println("[DIRECT-DEAL] QUERY ORDER - FAILED: " + ex.getMessage());
            throw new RequestQuoteException("QUERY_ORDER", HttpStatus.BAD_GATEWAY,
                    "Unable to parse Integral Query Order response: "
                            + ex.getMessage());
        }
    }

    private ResponseEntity<String> bookTrade(
            DirectDealRequest request,
            DirectDealOrderResponse order,
            String reversalValueDate,
            String ssoToken) {

        // Query Order can return 0 for averagePrice/cumQty when the order is
        // still NEW/RECEIVED. In that case use the values supplied in the
        // Direct Deal request instead of sending zero values to Book Trade.
        BigDecimal coverRate = order.getAveragePrice() != null
                && order.getAveragePrice().compareTo(BigDecimal.ZERO) > 0
                ? order.getAveragePrice()
                : request.getCoverRate();

        BigDecimal dealtAmount = order.getCumQty() != null
                && order.getCumQty().compareTo(BigDecimal.ZERO) > 0
                ? order.getCumQty()
                : request.getDealtAmount();

        // Exact Postman equivalent:
        // 'Reversal-' + origTransactionId + '-' + timestamp
        String reversalClientRequestId = "Reversal-"
                + request.getReferenceId()
                + "-"
                + System.currentTimeMillis();
        String reversalTradeBookingDate = LocalDate.now().toString();

        DirectDealBookTradeRequest tradeRequest =
                DirectDealBookTradeRequest.builder()
                        .type("Spot")
                        .channel(request.getChannel())
                        .clientRequestId(reversalClientRequestId)
                        .counterparty(request.getCounterparty())
                        .counterpartyAccount(request.getCounterpartyAccount())
                        .counterpartyTrader(request.getCounterpartyTrader())
                        .coverRate(coverRate)
                        .creditMode(request.getCreditMode())
                        .customerOrg(request.getCustomerOrg())
                        .customerAccount(request.getCustomerAccount())
                        .trader(request.getTrader())
                        .dealtAmount(dealtAmount)
                        .dealtIns(request.getDealtIns())
                        .note(request.getNote())
                        .rate(request.getRate())
                        .rateId(request.getRateId())
                        .referenceId(request.getReferenceId())
                        .side(toUpperCaseSide(request.getSide()))
                        .spotRate(request.getSpotRate())
                        .stp(request.getStp())
                        .symbol(request.getSymbol())
                        .tradeDate(reversalTradeBookingDate)
                        .valueDate(reversalValueDate)
                        .customParameters(toTradeCustomParameters(request))
                        .build();

        try {
            System.out.println("[DIRECT-DEAL] Calling Integral BOOK TRADE: POST /v2/trades");
            System.out.println("[DIRECT-DEAL] Book Trade clientRequestId: "
                    + tradeRequest.getClientRequestId());
            System.out.println("[DIRECT-DEAL] Book Trade tradeDate: "
                    + tradeRequest.getTradeDate());
            System.out.println("[DIRECT-DEAL] Book Trade valueDate: "
                    + tradeRequest.getValueDate());
            System.out.println("[DIRECT-DEAL] Book Trade symbol: "
                    + tradeRequest.getSymbol());
            System.out.println("[DIRECT-DEAL] Book Trade side: "
                    + tradeRequest.getSide());
            System.out.println("[DIRECT-DEAL] Book Trade dealtAmount: "
                    + tradeRequest.getDealtAmount());
            System.out.println("[DIRECT-DEAL] Book Trade coverRate: "
                    + tradeRequest.getCoverRate());

            ResponseEntity<String> response = bookTradeApi.bookTradeWithSso(tradeRequest, ssoToken);

            if (response == null) {
                throw new RequestQuoteException(
                        "BOOK_TRADE",
                        HttpStatus.BAD_GATEWAY,
                        "Integral Book Trade returned an empty response");
            }

            System.out.println("[DIRECT-DEAL] Integral BOOK TRADE HTTP status: "
                    + response.getStatusCode().value());
            System.out.println("[DIRECT-DEAL] Integral BOOK TRADE response: "
                    + response.getBody());

            validateSuccessfulResponse(response, "BOOK_TRADE");

            if (response.getBody() == null || response.getBody().isBlank()) {
                throw new RequestQuoteException(
                        "BOOK_TRADE",
                        HttpStatus.BAD_GATEWAY,
                        "Integral Book Trade returned an empty response body");
            }

            return response;
        } catch (RequestQuoteException ex) {
            System.out.println("[DIRECT-DEAL] STEP 4/4 - BOOK TRADE - FAILED: "
                    + ex.getMessage());
            throw ex;
        } catch (RestClientResponseException ex) {
            System.out.println("[DIRECT-DEAL] STEP 4/4 - BOOK TRADE - FAILED HTTP "
                    + ex.getStatusCode().value());
            System.out.println("[DIRECT-DEAL] BOOK TRADE error response: "
                    + ex.getResponseBodyAsString());
            throw new RequestQuoteException(
                    "BOOK_TRADE",
                    ex.getStatusCode(),
                    buildIntegralErrorMessage(
                            "Book Trade",
                            ex.getStatusCode().value(),
                            ex.getResponseBodyAsString()));
        } catch (Exception ex) {
            System.out.println("[DIRECT-DEAL] STEP 4/4 - BOOK TRADE - FAILED: "
                    + ex.getMessage());
            throw new RequestQuoteException(
                    "BOOK_TRADE",
                    HttpStatus.BAD_GATEWAY,
                    "Unable to call Integral Book Trade: " + ex.getMessage());
        }
    }

    private String generateClientOrderId() {
        return String.valueOf(System.currentTimeMillis());
    }

    /**
     * Exact equivalent of the Postman Reversal pre-request script:
     * add two business days and skip Saturday/Sunday.
     */
    private String calculateTPlusTwoBusinessDays() {
        LocalDate date = LocalDate.now();
        int added = 0;
        while (added < 2) {
            date = date.plusDays(1);
            DayOfWeek day = date.getDayOfWeek();
            if (day != DayOfWeek.SATURDAY && day != DayOfWeek.SUNDAY) {
                added++;
            }
        }

        return date.toString();
    }

    private String buildIntegralErrorMessage(
            String operation,
            int statusCode,
            String responseBody) {

        String body = responseBody == null ? "" : responseBody.trim();

        if (body.length() > 2000) {
            body = body.substring(0, 2000);
        }

        if (body.isBlank()) {
            return "Integral " + operation + " returned HTTP " + statusCode;
        }

        return "Integral " + operation
                + " returned HTTP " + statusCode
                + ". Response: " + body;
    }

    private void validateSuccessfulResponse(
            ResponseEntity<String> response,
            String step) {

        if (response == null) {
            throw new RequestQuoteException(
                    step,
                    HttpStatus.BAD_GATEWAY,
                    "Integral returned an empty response");
        }

        if (!response.getStatusCode().is2xxSuccessful()) {
            throw new RequestQuoteException(
                    step,
                    response.getStatusCode(),
                    "Integral " + step + " failed");
        }
    }

    private Map<String, String> toOrderCustomParameters(
            DirectDealRequest request) {
        return toCustomParameters(request);
    }

    private Map<String, String> toTradeCustomParameters(
            DirectDealRequest request) {
        return toCustomParameters(request);
    }

    private Map<String, String> toCustomParameters(
            DirectDealRequest request) {

        Map<String, String> customParameters = new LinkedHashMap<>();
        DirectDealRequest.CustomParameters source = request.getCustomParameters();

        if (source != null) {
            putIfPresent(customParameters, "CIF", source.getCif());
            putIfPresent(customParameters, "Channel", source.getChannel());
            putIfPresent(customParameters, "Settlement", source.getSettlement());
            putIfPresent(customParameters, "OBDXRef", source.getObdxRef());
            putIfPresent(customParameters, "OBPRef", source.getObpRef());
            putIfPresent(customParameters, "Ref", source.getRef());
            putIfPresent(customParameters, "Reversal", source.getReversal());
        }

        return customParameters;
    }

    private void putIfPresent(
            Map<String, String> target,
            String key,
            String value) {
        if (!isBlank(value)) {
            target.put(key, value);
        }
    }

    private void reqValidate(DirectDealRequest request) {
        if (request == null) {
            throw new RequestQuoteException(
                    "VALIDATION",
                    HttpStatus.BAD_REQUEST,
                    "Request body is required");
        }

        // Keep the incoming request contract intact. coId remains required as
        // the original/reference value, but the Integral Place Order coId is
        // intentionally generated fresh like Postman.
        require(request.getCoId(), "coId");
        require(request.getSymbol(), "symbol");
        require(request.getSide(), "side");
        require(request.getCurrency(), "currency");
        require(request.getValueDate(), "valueDate");
        require(request.getOrg(), "org");
        require(request.getAccount(), "account");
        require(request.getSource(), "source");
        require(request.getChannel(), "channel");
        require(request.getCustomerOrg(), "customerOrg");
        require(request.getCustomerAccount(), "customerAccount");
        require(request.getTrader(), "trader");
        require(request.getRateId(), "rateId");
        require(request.getReferenceId(), "referenceId");
        require(request.getTradeDate(), "tradeDate");
        require(request.getCounterparty(), "counterparty");
        require(request.getCounterpartyAccount(), "counterpartyAccount");
        require(request.getCounterpartyTrader(), "counterpartyTrader");
        require(request.getDealtIns(), "dealtIns");

        requirePositive(request.getSize(), "size");
        requirePositive(request.getCoverRate(), "coverRate");
        requirePositive(request.getRate(), "rate");
        requirePositive(request.getSpotRate(), "spotRate");
        requirePositive(request.getDealtAmount(), "dealtAmount");

        if (request.getCreditMode() == null) {
            throw new RequestQuoteException(
                    "VALIDATION",
                    HttpStatus.BAD_REQUEST,
                    "creditMode is required");
        }

        if (request.getStp() == null) {
            throw new RequestQuoteException(
                    "VALIDATION",
                    HttpStatus.BAD_REQUEST,
                    "stp is required");
        }

        validateSide(request.getSide());

        if (request.getCustomParameters() == null) {
            throw new RequestQuoteException(
                    "VALIDATION",
                    HttpStatus.BAD_REQUEST,
                    "customParameters is required");
        }

        DirectDealRequest.CustomParameters custom = request.getCustomParameters();
        require(custom.getChannel(), "customParameters.Channel");
        require(custom.getCif(), "customParameters.CIF");
        require(custom.getSettlement(), "customParameters.Settlement");
        require(custom.getReversal(), "customParameters.Reversal");

        if (isBlank(custom.getObdxRef())
                && isBlank(custom.getObpRef())
                && isBlank(custom.getRef())) {
            throw new RequestQuoteException(
                    "VALIDATION",
                    HttpStatus.BAD_REQUEST,
                    "customParameters.OBDXRef, customParameters.OBPRef or customParameters.Ref is required");
        }
    }

    private void validateSide(String side) {
        if (!"BUY".equalsIgnoreCase(side)
                && !"SELL".equalsIgnoreCase(side)) {
            throw new RequestQuoteException(
                    "VALIDATION",
                    HttpStatus.BAD_REQUEST,
                    "side must be BUY or SELL");
        }
    }

    private void requirePositive(BigDecimal value, String field) {
        if (value == null || value.compareTo(BigDecimal.ZERO) <= 0) {
            throw new RequestQuoteException(
                    "VALIDATION",
                    HttpStatus.BAD_REQUEST,
                    field + " must be greater than zero");
        }
    }

    private boolean isBlank(String value) {
        return value == null || value.isBlank();
    }

    private void require(String value, String field) {
        if (isBlank(value)) {
            throw new RequestQuoteException(
                    "VALIDATION",
                    HttpStatus.BAD_REQUEST,
                    field + " is required");
        }
    }

    private String toTitleCaseSide(String side) {
        return Character.toUpperCase(side.charAt(0))
                + side.substring(1).toLowerCase();
    }

    private String toUpperCaseSide(String side) {
        return side.toUpperCase();
    }
}
