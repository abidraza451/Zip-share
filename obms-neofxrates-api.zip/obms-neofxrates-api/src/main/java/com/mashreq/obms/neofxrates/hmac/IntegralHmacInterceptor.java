package com.mashreq.obms.neofxrates.hmac;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpRequest;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;
import java.io.IOException;
import java.nio.charset.StandardCharsets;


public class IntegralHmacInterceptor implements ClientHttpRequestInterceptor {

    private final IntegralHmacProperties properties;
    private final IntegralHmacService hmacService;

    public IntegralHmacInterceptor(
            IntegralHmacProperties properties,
            IntegralHmacService hmacService) {

        this.properties = properties;
        this.hmacService = hmacService;
    }
    @Override
    public ClientHttpResponse intercept(HttpRequest request, byte[] body, ClientHttpRequestExecution execution) throws IOException {
        if (!properties.isEnabled()) {
            return execution.execute(request, body);
        }
        HttpHeaders headers = request.getHeaders();
        String contentType = headers.getFirst(HttpHeaders.CONTENT_TYPE);
        String requestBody = new String(body == null ? new byte[0] : body, StandardCharsets.UTF_8);
        HmacResponse hmacResponse = hmacService.generateHmacHeaders(request.getMethod(), request.getURI().toString(), requestBody, contentType);
        headers.set(HttpHeaders.DATE, hmacResponse.getDate());
        headers.set("Digest", hmacResponse.getDigest());
        headers.set("type", hmacResponse.getType());
        headers.set(HttpHeaders.AUTHORIZATION, hmacResponse.getAuthorization());
        return execution.execute(request, body);
    }
}
