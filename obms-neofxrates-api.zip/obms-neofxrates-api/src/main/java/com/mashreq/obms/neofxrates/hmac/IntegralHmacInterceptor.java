package com.mashreq.obms.neofxrates.hmac;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpRequest;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.util.StringUtils;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.io.IOException;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Base64;
import java.util.Locale;

/**
 * Integral HMAC authentication compatible with the supplied Postman collection.
 *
 * Signing rules copied from the working Postman implementation:
 * - SHA-256 body digest is raw Base64 (no "SHA-256=" prefix).
 * - /v2 is removed from the path before building request-line.
 * - signing order is: date request-line digest.
 * - secret is UTF-8 by default (optional Base64 mode).
 * - Authorization uses the "username" parameter.
 */
public class IntegralHmacInterceptor implements ClientHttpRequestInterceptor {

    private final IntegralHmacProperties properties;

    public IntegralHmacInterceptor(IntegralHmacProperties properties) {
        this.properties = properties;
    }

    @Override
    public ClientHttpResponse intercept(HttpRequest request, byte[] body,
            ClientHttpRequestExecution execution) throws IOException {

        if (!properties.isEnabled() || isLoginRequest(request.getURI())) {
            return execution.execute(request, body);
        }

        if (!StringUtils.hasText(properties.getUsername())
                || !StringUtils.hasText(properties.getSecret())) {
            throw new IllegalStateException(
                    "Integral HMAC is enabled but app.hmac.username/app.hmac.secret are not configured");
        }

        HttpHeaders headers = request.getHeaders();
        String date = DateTimeFormatter.RFC_1123_DATE_TIME.format(ZonedDateTime.now(java.time.ZoneOffset.UTC));
        headers.set("Date", date);

        String digest = sha256Base64(body);
        headers.set("Digest", digest);
        headers.set("type", "hmac");

        String pathForSigning = getPathWithQuery(request.getURI());
        String stripPrefix = properties.getStripPathPrefix();
        if (StringUtils.hasText(stripPrefix) && pathForSigning.regionMatches(
                true, 0, stripPrefix, 0, stripPrefix.length())) {
            pathForSigning = pathForSigning.substring(stripPrefix.length());
        }
        if (!pathForSigning.startsWith("/")) {
            pathForSigning = "/" + pathForSigning;
        }

        String requestLine = request.getMethod().name() + " " + pathForSigning + " HTTP/1.1";

        String[] headersToSign = properties.getHeaders().toLowerCase(Locale.ROOT).trim().split("\\s+");
        StringBuilder signingString = new StringBuilder();

        for (int i = 0; i < headersToSign.length; i++) {
            if (i > 0) {
                signingString.append('\n');
            }
            String header = headersToSign[i];

            if ("request-line".equals(header)) {
                signingString.append(requestLine);
            }
            else if ("date".equals(header)) {
                signingString.append("date: ").append(date);
            }
            else if ("digest".equals(header)) {
                signingString.append("digest: ").append(digest);
            }
            else {
                signingString.append(header).append(": ")
                        .append(headers.getFirst(header) == null ? "" : headers.getFirst(header));
            }
        }

        String signature = hmacSha256Base64(signingString.toString(), properties.getSecret(), properties.getSecretEncoding());

        String authHeader = "hmac username=\""
                + properties.getUsername()
                + "\", algorithm=\"hmac-sha256\", headers=\""
                + String.join(" ", headersToSign)
                + "\", signature=\""
                + signature
                + "\"";

        headers.set(HttpHeaders.AUTHORIZATION, authHeader);

        return execution.execute(request, body);
    }

    private boolean isLoginRequest(URI uri) {
        String path = uri.getPath();
        return path != null && path.endsWith("/v2/sso/login");
    }

    private String getPathWithQuery(URI uri) {
        String path = uri.getRawPath();
        if (path == null || path.isEmpty()) {
            path = "/";
        }
        String query = uri.getRawQuery();
        return query == null || query.isEmpty()
                ? path
                : path + "?" + query;
    }

    private String sha256Base64(byte[] body) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            return Base64.getEncoder().encodeToString(digest.digest(body));
        } catch (Exception ex) {
            throw new IllegalStateException("Unable to calculate SHA-256 digest", ex);
        }
    }

    private String hmacSha256Base64(String value, String secret, String encoding) {
        try {
            byte[] key = "base64".equalsIgnoreCase(encoding) ? Base64.getDecoder().decode(secret) : secret.getBytes(StandardCharsets.UTF_8);

            Mac mac = Mac.getInstance("HmacSHA256");
            mac.init(new SecretKeySpec(key, "HmacSHA256"));
            byte[] result = mac.doFinal(value.getBytes(StandardCharsets.UTF_8));
            return Base64.getEncoder().encodeToString(result);
        } catch (Exception ex) {
            throw new IllegalStateException("Unable to calculate Integral HMAC signature", ex);
        }
    }
}
