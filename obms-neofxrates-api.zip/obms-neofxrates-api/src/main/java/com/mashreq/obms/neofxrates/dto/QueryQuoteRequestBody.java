package com.mashreq.obms.neofxrates.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

import java.time.LocalDate;

@Data
@JsonInclude(JsonInclude.Include.ALWAYS)
public class QueryQuoteRequestBody {
    private String debitCurrency;
    private String transferCurrency;
    private String payByIndicator;
    private LocalDate transactionDate;
    private String cif;
    private String refNo;
    private String source;

    public static QueryQuoteRequestBody from(IndicativeFxRateEnquiryRequest request) {
        QueryQuoteRequestBody body = new QueryQuoteRequestBody();
        body.setDebitCurrency(request.getDebitCurrency());
        body.setTransferCurrency(request.getTransferCurrency());
        body.setPayByIndicator(request.getPayByIndicator());
        body.setTransactionDate(request.getTransactionDate());
        body.setCif(request.getCif());
        body.setRefNo(request.getRefNo());
        body.setSource(request.getSource());
        return body;
    }
}
