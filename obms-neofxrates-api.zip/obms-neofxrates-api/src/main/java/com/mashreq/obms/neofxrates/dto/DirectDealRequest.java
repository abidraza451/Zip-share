package com.mashreq.obms.neofxrates.dto;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.math.BigDecimal;

@Data
public class DirectDealRequest {

    private String user;
    private String pass;
    private String org;

    private String coId;
    private String symbol;
    private String side;
    private BigDecimal size;
    private String currency;
    private String valueDate;
    private String account;
    private CustomParameters customParameters;
    private String source;
    private String channel;
    private String clientRequestId;
    private BigDecimal coverRate;
    private Integer creditMode;
    private String customerOrg;
    private String customerAccount;
    private String trader;
    private BigDecimal dealtAmount;
    private String note;
    private BigDecimal rate;
    private String rateId;
    private String referenceId;
    private BigDecimal spotRate;
    private String tradeDate;
    private String counterparty;
    private String counterpartyAccount;
    private String counterpartyTrader;
    private String dealtIns;
    private Boolean stp;

    @Data
    public static class CustomParameters {

        @JsonProperty("Channel")
        @JsonAlias("channel")
        private String channel;

        @JsonProperty("CIF")
        @JsonAlias("cif")
        private String cif;

        @JsonProperty("Settlement")
        @JsonAlias("settlement")
        private String settlement;

        @JsonProperty("OBDXRef")
        @JsonAlias({"obdxRef", "OBDXREF"})
        private String obdxRef;

        @JsonProperty("OBPRef")
        @JsonAlias({"obpRef", "OBPREF"})
        private String obpRef;

        @JsonProperty("Ref")
        @JsonAlias("ref")
        private String ref;

        @JsonProperty("Reversal")
        @JsonAlias("reversal")
        private String reversal;
    }
}
