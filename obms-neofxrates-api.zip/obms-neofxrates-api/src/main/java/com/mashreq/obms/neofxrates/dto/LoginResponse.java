package com.mashreq.obms.neofxrates.dto;

import lombok.Data;

@Data
public class LoginResponse {
    private String status;
    private Long expiryTime;
    private Long serverUTCTime;
}
