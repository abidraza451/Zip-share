package com.mashreq.obms.neofxrates.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
@AllArgsConstructor
public class AcceptQuoteRequest {

    private String quoteId;
    private String side;
    private String symbol;
    private String dealtCurrency;
    private String transactionId;
    private String clOrderId;
    private Boolean rfq;
}
