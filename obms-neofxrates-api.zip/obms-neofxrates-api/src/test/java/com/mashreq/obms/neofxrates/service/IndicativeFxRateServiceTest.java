package com.mashreq.obms.neofxrates.service;

import com.mashreq.obms.neofxrates.dto.*;
import com.mashreq.obms.neofxrates.exception.RequestQuoteException;
import com.mashreq.obms.neofxrates.hmac.IntegralHmacProperties;
import com.mashreq.obms.neofxrates.entity.TraditionalCurrencyPairDirection;
import com.mashreq.obms.neofxrates.repository.TraditionalCurrencyPairDirectionRepository;
import com.mashreq.obms.neofxrates.msApi.*;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.*;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;


import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class IndicativeFxRateServiceTest {

    @Mock FxIntegralLoginApi loginApi;
    @Mock FxIntegralRequestQuoteApi requestQuoteApi;
    @Mock FxIntegralQueryQuoteApi queryQuoteApi;
    @Mock TraditionalCurrencyPairDirectionRepository currencyPairRepository;
    @Spy ObjectMapper objectMapper = new ObjectMapper();
    @InjectMocks IndicativeFxRateService service;

    @BeforeEach
    void mockCurrencyPair() {
        TraditionalCurrencyPairDirection pair =
                new TraditionalCurrencyPairDirection(1L, "USD", "AED");
        lenient().when(currencyPairRepository.findByBaseCurrencyAndQuoteCurrency("AED", "USD"))
                .thenReturn(java.util.Optional.empty());
        lenient().when(currencyPairRepository.findByBaseCurrencyAndQuoteCurrency("USD", "AED"))
                .thenReturn(java.util.Optional.of(pair));
    }

    private IndicativeFxRateEnquiryRequest validRequest() {
        IndicativeFxRateEnquiryRequest r = new IndicativeFxRateEnquiryRequest();
        r.setUser("user");
        r.setPass("pass");
        r.setOrg("org");
        r.setDebitCurrency("AED");
        r.setTransferCurrency("USD");
        r.setPayByIndicator("D");
        r.setTransactionAmount(1000);
        r.setRefNo("RFQ-123");
        return r;
    }

    private LoginResponse loginOk() {
        LoginResponse r = new LoginResponse();
        r.setStatus("OK");
        return r;
    }

    private RequestQuoteResponse rfqAccepted() {
        RequestQuoteResponse r = new RequestQuoteResponse();
        r.setClOrderId("RFQ-123");
        r.setRequestId("REQ-123");
        r.setStatus("ACCEPTED");
        r.setEvent("REQUEST_ACCEPTED");
        return r;
    }

    @Test
    void fetchFxRate_returnsCompleteQueryQuoteResponse_andCallsQueryOnlyOnce() {
        when(loginApi.login(any(LoginRequest.class)))
                .thenReturn(ResponseEntity.ok(loginOk()));
        when(requestQuoteApi.requestQuote(any(RequestQuoteRequest.class)))
                .thenReturn(ResponseEntity.status(HttpStatus.ACCEPTED).body(rfqAccepted()));

        String quoteJson = "{\"event\":\"QUOTE\",\"quotes\":[{\"id\":\"Q1\",\"rate\":3.67}]}";
        when(queryQuoteApi.queryByServerId("REQ-123"))
                .thenReturn(ResponseEntity.ok(quoteJson));

        ResponseEntity<TsdFxRateEnquiryResponse> result = service.fetchFxRate(validRequest());

        assertEquals(HttpStatus.OK, result.getStatusCode());
        TsdFxRateEnquiryResponse response = result.getBody();
        assertNotNull(response);
        assertNotNull(response.getData());
        assertEquals("QUOTE", response.getData().get("event"));
        assertEquals("SELL", response.getData().get("side"));
        assertEquals(Boolean.TRUE, response.getData().get("rfq"));
        assertNull(response.getData().get("cachedRate"));
        assertEquals("AED", response.getRequestBody().getDebitCurrency());
        assertEquals("USD", response.getRequestBody().getTransferCurrency());
        assertEquals("D", response.getRequestBody().getPayByIndicator());
        assertEquals("RFQ-123", response.getRequestBody().getRefNo());
        assertEquals("Y", response.getData().get("inverse"));
        assertNull(response.getData().get("reciprocalRate"));

        ArgumentCaptor<RequestQuoteRequest> captor =
                ArgumentCaptor.forClass(RequestQuoteRequest.class);
        verify(requestQuoteApi).requestQuote(captor.capture());
        assertEquals("RFQ-123", captor.getValue().getClOrderId());
        assertEquals(1000, captor.getValue().getAmount());
        assertEquals("AED", captor.getValue().getDealtCurrency());
        assertEquals("SELL", captor.getValue().getSide());
        assertEquals("USD/AED", captor.getValue().getSymbol());

        verify(queryQuoteApi, times(1)).queryByServerId("REQ-123");
    }



    @Test
    void fetchFxRate_preservesIntegralDataAndTsdFields() {
        when(loginApi.login(any())).thenReturn(ResponseEntity.ok(loginOk()));
        when(requestQuoteApi.requestQuote(any()))
                .thenReturn(ResponseEntity.status(HttpStatus.ACCEPTED).body(rfqAccepted()));

        String quoteJson = """
                {
                  "data": {
                    "clOrderId": "RFQ-123",
                    "requestId": "REQ-123",
                    "transactionId": "TX-1",
                    "ttl": 120,
                    "event": "QUOTE",
                    "quotes": []
                  },
                  "cachedRate": 1.18296
                }
                """;

        when(queryQuoteApi.queryByServerId("REQ-123"))
                .thenReturn(ResponseEntity.ok(quoteJson));

        ResponseEntity<TsdFxRateEnquiryResponse> result = service.fetchFxRate(validRequest());

        TsdFxRateEnquiryResponse response = result.getBody();
        assertNotNull(response);
        assertEquals("RFQ-123", response.getData().get("clOrderId"));
        assertEquals("REQ-123", response.getData().get("requestId"));
        assertEquals("TX-1", response.getData().get("transactionId"));
        assertEquals(120, ((Number) response.getData().get("ttl")).intValue());
        assertEquals("QUOTE", response.getData().get("event"));
        assertEquals("SELL", response.getData().get("side"));
        assertEquals(Boolean.TRUE, response.getData().get("rfq"));
        assertEquals(1.18296, ((Number) response.getData().get("cachedRate")).doubleValue(), 0.000001);
        assertEquals("AED", response.getRequestBody().getDebitCurrency());
        assertEquals("USD", response.getRequestBody().getTransferCurrency());
        assertEquals("D", response.getRequestBody().getPayByIndicator());
        assertEquals("RFQ-123", response.getRequestBody().getRefNo());
    }

    @Test
    void fetchFxRate_responseSerializesAsTsdJsonWithoutJsonNodeMetadata() throws Exception {
        when(loginApi.login(any())).thenReturn(ResponseEntity.ok(loginOk()));
        when(requestQuoteApi.requestQuote(any()))
                .thenReturn(ResponseEntity.status(HttpStatus.ACCEPTED).body(rfqAccepted()));
        when(queryQuoteApi.queryByServerId("REQ-123"))
                .thenReturn(ResponseEntity.ok("""
                        {
                          "clOrderId": "RFQ-123",
                          "requestId": "REQ-123",
                          "transactionId": "TX-1",
                          "ttl": 120,
                          "event": "QUOTE",
                          "quotes": []
                        }
                        """));

        ResponseEntity<TsdFxRateEnquiryResponse> result = service.fetchFxRate(validRequest());
        String json = objectMapper.writeValueAsString(result.getBody());

        JsonNode root = objectMapper.readTree(json);
        assertTrue(root.has("data"));
        assertTrue(root.get("data").isObject());
        assertEquals("RFQ-123", root.at("/data/clOrderId").asText());
        assertEquals("QUOTE", root.at("/data/event").asText());
        assertEquals("SELL", root.at("/data/side").asText());
        assertTrue(root.at("/data/rfq").asBoolean());
        assertTrue(root.at("/data").has("cachedRate"));
        assertTrue(root.at("/data/cachedRate").isNull());
        assertFalse(root.has("cachedRate"));
        assertTrue(root.has("requestBody"));
        assertEquals("AED", root.at("/requestBody/debitCurrency").asText());
        assertFalse(json.contains("nodeType"));
        assertFalse(json.contains("containerNode"));
        assertFalse(json.contains("bigDecimal"));
    }


    @Test
    void fetchFxRate_withTransferPayIndicator_buildsBuyRequest() {
        IndicativeFxRateEnquiryRequest request = validRequest();
        request.setPayByIndicator("T");
        request.setTransferCurrency("USD");

        when(loginApi.login(any())).thenReturn(ResponseEntity.ok(loginOk()));
        when(requestQuoteApi.requestQuote(any()))
                .thenReturn(ResponseEntity.status(HttpStatus.ACCEPTED).body(rfqAccepted()));
        when(queryQuoteApi.queryByServerId(anyString()))
                .thenReturn(ResponseEntity.ok("{}"));

        service.fetchFxRate(request);

        ArgumentCaptor<RequestQuoteRequest> captor =
                ArgumentCaptor.forClass(RequestQuoteRequest.class);
        verify(requestQuoteApi).requestQuote(captor.capture());
        assertEquals("USD", captor.getValue().getDealtCurrency());
        assertEquals("BUY", captor.getValue().getSide());
        assertEquals("USD/AED", captor.getValue().getSymbol());
    }

    @Test
    void fetchFxRate_generatesRefNoWhenMissing() {
        IndicativeFxRateEnquiryRequest request = validRequest();
        request.setRefNo(" ");

        when(loginApi.login(any())).thenReturn(ResponseEntity.ok(loginOk()));
        when(requestQuoteApi.requestQuote(any()))
                .thenAnswer(inv -> {
                    RequestQuoteRequest rq = inv.getArgument(0);
                    assertTrue(rq.getClOrderId().startsWith("RFQ_"));
                    return ResponseEntity.status(HttpStatus.ACCEPTED).body(rfqAccepted());
                });
        when(queryQuoteApi.queryByServerId(anyString()))
                .thenReturn(ResponseEntity.ok("{}"));

        service.fetchFxRate(request);

        assertNotNull(request.getRefNo());
        assertTrue(request.getRefNo().startsWith("RFQ_"));
    }

    @Test
    void fetchFxRate_normalDirection_setsInverseNReciprocalAndCalculatesSettledAmount() {
        IndicativeFxRateEnquiryRequest request = validRequest();
        request.setPayByIndicator("T");
        request.setTransferCurrency("USD");

        when(loginApi.login(any())).thenReturn(ResponseEntity.ok(loginOk()));
        when(requestQuoteApi.requestQuote(any()))
                .thenReturn(ResponseEntity.status(HttpStatus.ACCEPTED).body(rfqAccepted()));
        when(queryQuoteApi.queryByServerId("REQ-123"))
                .thenReturn(ResponseEntity.ok("""
                        {
                          "event":"QUOTE",
                          "quotes":[{
                            "symbol":"USD/AED",
                            "offers":[{
                              "dealtAmount":1000.0,
                              "settledAmount":0.0,
                              "rate":3.67
                            }]
                          }]
                        }
                        """));

        ResponseEntity<TsdFxRateEnquiryResponse> result = service.fetchFxRate(request);

        MapAssertions.assertNumber(result.getBody().getData().get("reciprocalRate"), 1.0 / 3.67);
        assertEquals("N", result.getBody().getData().get("inverse"));
        Object settled = ((java.util.Map<?, ?>) ((java.util.List<?>) result.getBody().getData().get("quotes")).get(0));
        java.util.List<?> offers = (java.util.List<?>) ((java.util.Map<?, ?>) settled).get("offers");
        java.util.Map<?, ?> offer = (java.util.Map<?, ?>) offers.get(0);
        MapAssertions.assertNumber(offer.get("settledAmount"), 3670.0);
    }

    @Test
    void fetchFxRate_inverseDirection_withBids_setsReciprocalAndSettledAmount() {
        IndicativeFxRateEnquiryRequest request = validRequest();

        when(loginApi.login(any())).thenReturn(ResponseEntity.ok(loginOk()));
        when(requestQuoteApi.requestQuote(any()))
                .thenReturn(ResponseEntity.status(HttpStatus.ACCEPTED).body(rfqAccepted()));
        when(queryQuoteApi.queryByServerId("REQ-123"))
                .thenReturn(ResponseEntity.ok("""
                        {
                          "event":"QUOTE",
                          "quotes":[{
                            "symbol":"USD/AED",
                            "dealtCurrency":"AED",
                            "bids":[{
                              "dealtAmount":5000.0,
                              "settledAmount":4491.03,
                              "rate":1.11333
                            }]
                          }]
                        }
                        """));

        ResponseEntity<TsdFxRateEnquiryResponse> result = service.fetchFxRate(request);

        assertEquals("Y", result.getBody().getData().get("inverse"));
        MapAssertions.assertNumber(
                result.getBody().getData().get("reciprocalRate"),
                1.0 / 1.11333);

        java.util.Map<?, ?> quote =
                (java.util.Map<?, ?>) ((java.util.List<?>) result.getBody().getData().get("quotes")).get(0);
        java.util.List<?> bids = (java.util.List<?>) quote.get("bids");
        java.util.Map<?, ?> bid = (java.util.Map<?, ?>) bids.get(0);

        MapAssertions.assertNumber(bid.get("settledAmount"), 4491.03);
    }

@Test
    void fetchFxRate_inverseDirection_dividesSettledAmount() {
        IndicativeFxRateEnquiryRequest request = validRequest();
        request.setPayByIndicator("D");
        request.setDebitCurrency("AED");
        request.setTransferCurrency("USD");

        when(loginApi.login(any())).thenReturn(ResponseEntity.ok(loginOk()));
        when(requestQuoteApi.requestQuote(any()))
                .thenReturn(ResponseEntity.status(HttpStatus.ACCEPTED).body(rfqAccepted()));
        when(queryQuoteApi.queryByServerId("REQ-123"))
                .thenReturn(ResponseEntity.ok("""
                        {
                          "event":"QUOTE",
                          "quotes":[{
                            "symbol":"USD/AED",
                            "offers":[{
                              "dealtAmount":1000.0,
                              "settledAmount":0.0,
                              "rate":3.67
                            }]
                          }]
                        }
                        """));

        ResponseEntity<TsdFxRateEnquiryResponse> result = service.fetchFxRate(request);

        assertEquals("Y", result.getBody().getData().get("inverse"));
        MapAssertions.assertNumber(result.getBody().getData().get("reciprocalRate"), 1.0 / 3.67);
        java.util.Map<?, ?> quote = (java.util.Map<?, ?>) ((java.util.List<?>) result.getBody().getData().get("quotes")).get(0);
        java.util.Map<?, ?> offer = (java.util.Map<?, ?>) ((java.util.List<?>) quote.get("offers")).get(0);
        MapAssertions.assertNumber(offer.get("settledAmount"), 1000.0 / 3.67);
    }

    @Test
    void fetchFxRate_missingCurrencyPair_failsBeforeLogin() {
        IndicativeFxRateEnquiryRequest request = validRequest();
        when(currencyPairRepository.findByBaseCurrencyAndQuoteCurrency("AED", "USD"))
                .thenReturn(java.util.Optional.empty());
        when(currencyPairRepository.findByBaseCurrencyAndQuoteCurrency("USD", "AED"))
                .thenReturn(java.util.Optional.empty());

        RequestQuoteException ex = assertThrows(RequestQuoteException.class,
                () -> service.fetchFxRate(request));

        assertEquals("CURRENCY_PAIR", ex.getStep());
        assertEquals(HttpStatus.BAD_REQUEST, ex.getStatusCode());
        verifyNoInteractions(loginApi, requestQuoteApi, queryQuoteApi);
    }

    @Test
    void fetchFxRate_nullRequest_throwsBadRequest() {
        RequestQuoteException ex =
                assertThrows(RequestQuoteException.class, () -> service.fetchFxRate(null));

        assertEquals(HttpStatus.BAD_REQUEST, ex.getStatusCode());
        assertEquals("VALIDATION", ex.getStep());
    }

    @Test
    void fetchFxRate_missingLoginUser_throwsBadRequest() {
        IndicativeFxRateEnquiryRequest r = validRequest();
        r.setUser(null);

        assertThrows(RequestQuoteException.class, () -> service.fetchFxRate(r));
        verifyNoInteractions(loginApi, requestQuoteApi, queryQuoteApi);
    }

    @Test
    void fetchFxRate_missingPassword_throwsBadRequest() {
        IndicativeFxRateEnquiryRequest r = validRequest();
        r.setPass(" ");

        assertThrows(RequestQuoteException.class, () -> service.fetchFxRate(r));
        verifyNoInteractions(loginApi, requestQuoteApi, queryQuoteApi);
    }

    @Test
    void fetchFxRate_missingOrg_throwsBadRequest() {
        IndicativeFxRateEnquiryRequest r = validRequest();
        r.setOrg("");

        assertThrows(RequestQuoteException.class, () -> service.fetchFxRate(r));
        verifyNoInteractions(loginApi, requestQuoteApi, queryQuoteApi);
    }

    @Test
    void fetchFxRate_missingDebitCurrency_throwsBadRequest() {
        IndicativeFxRateEnquiryRequest r = validRequest();
        r.setDebitCurrency(" ");

        assertThrows(RequestQuoteException.class, () -> service.fetchFxRate(r));
        verifyNoInteractions(loginApi, requestQuoteApi, queryQuoteApi);
    }

    @Test
    void fetchFxRate_missingTransferCurrency_throwsBadRequest() {
        IndicativeFxRateEnquiryRequest r = validRequest();
        r.setTransferCurrency(null);

        assertThrows(RequestQuoteException.class, () -> service.fetchFxRate(r));
        verifyNoInteractions(loginApi, requestQuoteApi, queryQuoteApi);
    }

    @Test
    void fetchFxRate_missingPayByIndicator_throwsBadRequest() {
        IndicativeFxRateEnquiryRequest r = validRequest();
        r.setPayByIndicator(null);

        assertThrows(RequestQuoteException.class, () -> service.fetchFxRate(r));
        verifyNoInteractions(loginApi, requestQuoteApi, queryQuoteApi);
    }

    @Test
    void fetchFxRate_invalidPayByIndicator_throwsBadRequest() {
        IndicativeFxRateEnquiryRequest r = validRequest();
        r.setPayByIndicator("X");

        RequestQuoteException ex =
                assertThrows(RequestQuoteException.class, () -> service.fetchFxRate(r));

        assertEquals(HttpStatus.BAD_REQUEST, ex.getStatusCode());
        verifyNoInteractions(loginApi, requestQuoteApi, queryQuoteApi);
    }

    @Test
    void fetchFxRate_missingTransactionAmount_throwsBadRequest() {
        IndicativeFxRateEnquiryRequest r = validRequest();
        r.setTransactionAmount(null);

        assertThrows(RequestQuoteException.class, () -> service.fetchFxRate(r));
        verifyNoInteractions(loginApi, requestQuoteApi, queryQuoteApi);
    }

    @Test
    void fetchFxRate_loginReturnsNullResponse_throwsBadGateway() {
        when(loginApi.login(any())).thenReturn(null);

        RequestQuoteException ex =
                assertThrows(RequestQuoteException.class, () -> service.fetchFxRate(validRequest()));

        assertEquals("LOGIN", ex.getStep());
        assertEquals(HttpStatus.BAD_GATEWAY, ex.getStatusCode());
        verifyNoInteractions(requestQuoteApi, queryQuoteApi);
    }

    @Test
    void fetchFxRate_loginReturnsNullBody_throwsBadGateway() {
        when(loginApi.login(any())).thenReturn(ResponseEntity.ok(null));

        RequestQuoteException ex =
                assertThrows(RequestQuoteException.class, () -> service.fetchFxRate(validRequest()));

        assertEquals("LOGIN", ex.getStep());
        assertEquals(HttpStatus.BAD_GATEWAY, ex.getStatusCode());
    }

    @Test
    void fetchFxRate_loginReturnsNon2xx_throwsBadGateway() {
        when(loginApi.login(any()))
                .thenReturn(ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(loginOk()));

        RequestQuoteException ex =
                assertThrows(RequestQuoteException.class, () -> service.fetchFxRate(validRequest()));

        assertEquals("LOGIN", ex.getStep());
        assertEquals(HttpStatus.UNAUTHORIZED, ex.getStatusCode());
    }

    @Test
    void fetchFxRate_loginBodyStatusNotOk_throwsBadGateway() {
        LoginResponse login = new LoginResponse();
        login.setStatus("FAILED");
        when(loginApi.login(any())).thenReturn(ResponseEntity.ok(login));

        RequestQuoteException ex =
                assertThrows(RequestQuoteException.class, () -> service.fetchFxRate(validRequest()));

        assertEquals("LOGIN", ex.getStep());
        assertEquals(HttpStatus.BAD_GATEWAY, ex.getStatusCode());
    }

    @Test
    void fetchFxRate_loginRestClientError_isMapped() {
        when(loginApi.login(any()))
                .thenThrow(HttpClientErrorException.create(
                        HttpStatus.UNAUTHORIZED, "Unauthorized", HttpHeaders.EMPTY, null, null));

        RequestQuoteException ex =
                assertThrows(RequestQuoteException.class, () -> service.fetchFxRate(validRequest()));

        assertEquals("LOGIN", ex.getStep());
        assertEquals(HttpStatus.UNAUTHORIZED, ex.getStatusCode());
    }

    @Test
    void fetchFxRate_loginUnexpectedError_isMapped() {
        when(loginApi.login(any())).thenThrow(new RuntimeException("connection failed"));

        RequestQuoteException ex =
                assertThrows(RequestQuoteException.class, () -> service.fetchFxRate(validRequest()));

        assertEquals("LOGIN", ex.getStep());
        assertEquals(HttpStatus.BAD_GATEWAY, ex.getStatusCode());
        assertTrue(ex.getMessage().contains("connection failed"));
    }

    @Test
    void fetchFxRate_requestQuoteReturnsNullResponse_throwsBadGateway() {
        when(loginApi.login(any())).thenReturn(ResponseEntity.ok(loginOk()));
        when(requestQuoteApi.requestQuote(any())).thenReturn(null);

        RequestQuoteException ex =
                assertThrows(RequestQuoteException.class, () -> service.fetchFxRate(validRequest()));

        assertEquals("REQUEST_QUOTE", ex.getStep());
        assertEquals(HttpStatus.BAD_GATEWAY, ex.getStatusCode());
        verifyNoInteractions(queryQuoteApi);
    }

    @Test
    void fetchFxRate_requestQuoteReturnsWrongStatus_throwsExpectedStatus() {
        when(loginApi.login(any())).thenReturn(ResponseEntity.ok(loginOk()));
        when(requestQuoteApi.requestQuote(any()))
                .thenReturn(ResponseEntity.status(HttpStatus.OK).body(rfqAccepted()));

        RequestQuoteException ex =
                assertThrows(RequestQuoteException.class, () -> service.fetchFxRate(validRequest()));

        assertEquals("REQUEST_QUOTE", ex.getStep());
        assertEquals(HttpStatus.OK, ex.getStatusCode());
        verifyNoInteractions(queryQuoteApi);
    }

    @Test
    void fetchFxRate_requestQuoteReturnsNullBody_throwsBadGateway() {
        when(loginApi.login(any())).thenReturn(ResponseEntity.ok(loginOk()));
        when(requestQuoteApi.requestQuote(any()))
                .thenReturn(ResponseEntity.status(HttpStatus.ACCEPTED).body(null));

        RequestQuoteException ex =
                assertThrows(RequestQuoteException.class, () -> service.fetchFxRate(validRequest()));

        assertEquals("REQUEST_QUOTE", ex.getStep());
        assertEquals(HttpStatus.BAD_GATEWAY, ex.getStatusCode());
        verifyNoInteractions(queryQuoteApi);
    }

    @Test
    void fetchFxRate_requestQuoteReturnsBlankRequestId_throwsBadGateway() {
        RequestQuoteResponse response = rfqAccepted();
        response.setRequestId(" ");

        when(loginApi.login(any())).thenReturn(ResponseEntity.ok(loginOk()));
        when(requestQuoteApi.requestQuote(any()))
                .thenReturn(ResponseEntity.status(HttpStatus.ACCEPTED).body(response));

        RequestQuoteException ex =
                assertThrows(RequestQuoteException.class, () -> service.fetchFxRate(validRequest()));

        assertEquals("REQUEST_QUOTE", ex.getStep());
        assertEquals(HttpStatus.BAD_GATEWAY, ex.getStatusCode());
        verifyNoInteractions(queryQuoteApi);
    }

    @Test
    void fetchFxRate_requestQuoteRestClientError_isMapped() {
        when(loginApi.login(any())).thenReturn(ResponseEntity.ok(loginOk()));
        when(requestQuoteApi.requestQuote(any()))
                .thenThrow(HttpServerErrorException.create(
                        HttpStatus.BAD_GATEWAY, "Bad Gateway", HttpHeaders.EMPTY, null, null));

        RequestQuoteException ex =
                assertThrows(RequestQuoteException.class, () -> service.fetchFxRate(validRequest()));

        assertEquals("REQUEST_QUOTE", ex.getStep());
        assertEquals(HttpStatus.BAD_GATEWAY, ex.getStatusCode());
        verifyNoInteractions(queryQuoteApi);
    }

    @Test
    void fetchFxRate_queryQuoteReturnsNullResponse_throwsBadGateway() {
        when(loginApi.login(any())).thenReturn(ResponseEntity.ok(loginOk()));
        when(requestQuoteApi.requestQuote(any()))
                .thenReturn(ResponseEntity.status(HttpStatus.ACCEPTED).body(rfqAccepted()));
        when(queryQuoteApi.queryByServerId(anyString())).thenReturn(null);

        RequestQuoteException ex =
                assertThrows(RequestQuoteException.class, () -> service.fetchFxRate(validRequest()));

        assertEquals("QUERY_QUOTE", ex.getStep());
        assertEquals(HttpStatus.BAD_GATEWAY, ex.getStatusCode());
        verify(queryQuoteApi, times(1)).queryByServerId("REQ-123");
    }

    @Test
    void fetchFxRate_queryQuoteReturnsNon2xx_throwsExpectedStatus() {
        when(loginApi.login(any())).thenReturn(ResponseEntity.ok(loginOk()));
        when(requestQuoteApi.requestQuote(any()))
                .thenReturn(ResponseEntity.status(HttpStatus.ACCEPTED).body(rfqAccepted()));
        when(queryQuoteApi.queryByServerId(anyString()))
                .thenReturn(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("error"));

        RequestQuoteException ex =
                assertThrows(RequestQuoteException.class, () -> service.fetchFxRate(validRequest()));

        assertEquals("QUERY_QUOTE", ex.getStep());
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, ex.getStatusCode());
        verify(queryQuoteApi, times(1)).queryByServerId("REQ-123");
    }

    @Test
    void fetchFxRate_queryQuoteReturnsBlankBody_throwsBadGateway() {
        when(loginApi.login(any())).thenReturn(ResponseEntity.ok(loginOk()));
        when(requestQuoteApi.requestQuote(any()))
                .thenReturn(ResponseEntity.status(HttpStatus.ACCEPTED).body(rfqAccepted()));
        when(queryQuoteApi.queryByServerId(anyString()))
                .thenReturn(ResponseEntity.ok(" "));

        RequestQuoteException ex =
                assertThrows(RequestQuoteException.class, () -> service.fetchFxRate(validRequest()));

        assertEquals("QUERY_QUOTE", ex.getStep());
        assertEquals(HttpStatus.BAD_GATEWAY, ex.getStatusCode());
    }

    @Test
    void fetchFxRate_queryQuoteRestClientError_isMapped() {
        when(loginApi.login(any())).thenReturn(ResponseEntity.ok(loginOk()));
        when(requestQuoteApi.requestQuote(any()))
                .thenReturn(ResponseEntity.status(HttpStatus.ACCEPTED).body(rfqAccepted()));
        when(queryQuoteApi.queryByServerId(anyString()))
                .thenThrow(HttpClientErrorException.create(
                        HttpStatus.NOT_FOUND, "Not Found", HttpHeaders.EMPTY, null, null));

        RequestQuoteException ex =
                assertThrows(RequestQuoteException.class, () -> service.fetchFxRate(validRequest()));

        assertEquals("QUERY_QUOTE", ex.getStep());
        assertEquals(HttpStatus.NOT_FOUND, ex.getStatusCode());
    }

    @Test
    void fetchFxRate_queryQuoteUnexpectedError_isMapped() {
        when(loginApi.login(any())).thenReturn(ResponseEntity.ok(loginOk()));
        when(requestQuoteApi.requestQuote(any()))
                .thenReturn(ResponseEntity.status(HttpStatus.ACCEPTED).body(rfqAccepted()));
        when(queryQuoteApi.queryByServerId(anyString()))
                .thenThrow(new RuntimeException("timeout"));

        RequestQuoteException ex =
                assertThrows(RequestQuoteException.class, () -> service.fetchFxRate(validRequest()));

        assertEquals("QUERY_QUOTE", ex.getStep());
        assertEquals(HttpStatus.BAD_GATEWAY, ex.getStatusCode());
    }

    @Test
    void fetchFxRate_interruptedWhileWaiting_restoresInterruptAndThrows() {
        when(loginApi.login(any())).thenReturn(ResponseEntity.ok(loginOk()));
        when(requestQuoteApi.requestQuote(any()))
                .thenReturn(ResponseEntity.status(HttpStatus.ACCEPTED).body(rfqAccepted()));

        Thread.currentThread().interrupt();
        try {
            RequestQuoteException ex =
                    assertThrows(RequestQuoteException.class, () -> service.fetchFxRate(validRequest()));

            assertEquals("QUERY_QUOTE", ex.getStep());
            assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, ex.getStatusCode());
            verifyNoInteractions(queryQuoteApi);
            assertTrue(Thread.currentThread().isInterrupted());
        } finally {
            Thread.interrupted(); // clear flag for following tests
        }
    }

    private static final class MapAssertions {
        private static void assertNumber(Object actual, double expected) {
            assertNotNull(actual);
            assertEquals(expected, ((Number) actual).doubleValue(), 0.00000001);
        }
    }

}
