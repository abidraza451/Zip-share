package com.mashreq.obms.neofxrates.controller;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mashreq.obms.neofxrates.dto.IndicativeFxRateEnquiryRequest;
import com.mashreq.obms.neofxrates.service.IndicativeFxRateService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class IndicativeFxEnquiryControllerTest {

    @Mock IndicativeFxRateService service;
    @InjectMocks
    NeoFxController controller;

    @Test
    void acceptQuote_delegatesToServiceAndReturnsResponse() {
        IndicativeFxRateEnquiryRequest request = new IndicativeFxRateEnquiryRequest();
        JsonNode responseBody = new ObjectMapper().createObjectNode().put("event", "QUOTE");
        ResponseEntity<JsonNode> expected = ResponseEntity.ok(responseBody);

        when(service.fetchFxRate(request)).thenReturn(expected);

        ResponseEntity<JsonNode> actual = controller.acceptQuote(request);

        assertSame(expected, actual);
        verify(service, times(1)).fetchFxRate(request);
    }

    @Test
    void acceptQuote_propagatesServiceException() {
        IndicativeFxRateEnquiryRequest request = new IndicativeFxRateEnquiryRequest();
        RuntimeException exception = new RuntimeException("failure");
        when(service.fetchFxRate(request)).thenThrow(exception);

        RuntimeException actual =
                assertThrows(RuntimeException.class, () -> controller.acceptQuote(request));

        assertSame(exception, actual);
        verify(service).fetchFxRate(request);
    }
}
