package com.mashreq.obms.neofxrates.config;

import com.mashreq.obms.neofxrates.hmac.IntegralHmacInterceptor;
import com.mashreq.obms.neofxrates.hmac.IntegralHmacProperties;
import com.mashreq.obms.neofxrates.hmac.IntegralHmacService;
import org.junit.jupiter.api.Test;
import org.springframework.web.client.RestTemplate;

import static org.junit.jupiter.api.Assertions.*;

class RestTemplateConfigTest {

    private final RestTemplateConfig config = new RestTemplateConfig();

    @Test
    void integralHmacService_createsServiceUsingProperties() {
        IntegralHmacProperties properties = new IntegralHmacProperties();

        IntegralHmacService service = config.integralHmacService(properties);

        assertNotNull(service);
    }

    @Test
    void restTemplate_createsTemplateWithHmacInterceptor() {
        IntegralHmacProperties properties = new IntegralHmacProperties();
        IntegralHmacService service = config.integralHmacService(properties);

        RestTemplate restTemplate = config.restTemplate(properties, service);

        assertNotNull(restTemplate);
        assertEquals(1, restTemplate.getInterceptors().size());
        assertInstanceOf(IntegralHmacInterceptor.class,
                restTemplate.getInterceptors().get(0));
    }
}
