package com.mashreq.obms.neofxrates.dto;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class RequestQuoteRequestTest {

    private IndicativeFxRateEnquiryRequest request(String indicator) {
        IndicativeFxRateEnquiryRequest r = new IndicativeFxRateEnquiryRequest();
        r.setRefNo("RFQ-1");
        r.setTransactionAmount(500);
        r.setDebitCurrency("AED");
        r.setTransferCurrency("USD");
        r.setPayByIndicator(indicator);
        return r;
    }

    @Test
    void calculate_forDebit_setsSellDebitCurrencyAndDatabaseSymbol() {
        RequestQuoteRequest result =
                new RequestQuoteRequest().calculate(request("D"), "USD/AED");

        assertEquals("RFQ-1", result.getClOrderId());
        assertEquals("USD/AED", result.getSymbol());
        assertEquals(500, result.getAmount());
        assertEquals("AED", result.getDealtCurrency());
        assertEquals("SELL", result.getSide());
    }

    @Test
    void calculate_forTransfer_setsBuyTransferCurrencyAndDatabaseSymbol() {
        RequestQuoteRequest result =
                new RequestQuoteRequest().calculate(request("T"), "USD/AED");

        assertEquals("USD/AED", result.getSymbol());
        assertEquals("USD", result.getDealtCurrency());
        assertEquals("BUY", result.getSide());
    }

    @Test
    void calculate_isCaseInsensitive() {
        RequestQuoteRequest result =
                new RequestQuoteRequest().calculate(request("d"), "USD/AED");

        assertEquals("SELL", result.getSide());
    }

    @Test
    void calculate_nullRequest_throwsException() {
        assertThrows(IllegalArgumentException.class,
                () -> new RequestQuoteRequest().calculate(null, "USD/AED"));
    }

    @Test
    void calculate_blankSymbol_throwsException() {
        assertThrows(IllegalArgumentException.class,
                () -> new RequestQuoteRequest().calculate(request("D"), " "));
    }

    @Test
    void calculate_unknownIndicator_leavesCalculatedFieldsUnset() {
        RequestQuoteRequest result =
                new RequestQuoteRequest().calculate(request("X"), "USD/AED");

        assertEquals("USD/AED", result.getSymbol());
        assertNull(result.getDealtCurrency());
        assertNull(result.getSide());
    }
}
