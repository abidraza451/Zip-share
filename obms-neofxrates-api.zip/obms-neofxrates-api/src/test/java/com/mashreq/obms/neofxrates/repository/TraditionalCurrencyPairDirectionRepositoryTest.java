package com.mashreq.obms.neofxrates.repository;

import com.mashreq.obms.neofxrates.entity.TraditionalCurrencyPairDirection;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;

@DataJpaTest
class TraditionalCurrencyPairDirectionRepositoryTest {

    @Autowired
    private TraditionalCurrencyPairDirectionRepository repository;

    @Test
    void shouldSaveAndFindCurrencyPair() {
        TraditionalCurrencyPairDirection pair =
                new TraditionalCurrencyPairDirection(null, "USD", "AED");

        TraditionalCurrencyPairDirection saved = repository.save(pair);

        assertThat(saved.getId()).isNotNull();

        Optional<TraditionalCurrencyPairDirection> result =
                repository.findByBaseCurrencyAndQuoteCurrency("USD", "AED");

        assertThat(result).isPresent();
        assertThat(result.get().getBaseCurrency()).isEqualTo("USD");
        assertThat(result.get().getQuoteCurrency()).isEqualTo("AED");
    }
}
