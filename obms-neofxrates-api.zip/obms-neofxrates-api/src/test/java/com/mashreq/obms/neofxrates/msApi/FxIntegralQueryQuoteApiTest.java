package com.mashreq.obms.neofxrates.msApi;

import com.mashreq.obms.neofxrates.config.ApplicationConfig;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class FxIntegralQueryQuoteApiTest {

    @Mock
    private ApplicationConfig applicationConfig;

    @Mock
    private RestTemplate restTemplate;

    @InjectMocks
    private FxIntegralQueryQuoteApi api;

    @Test
    void queryByClientId_buildsExpectedUrlAndGetRequest() {
        when(applicationConfig.getBaseUrl()).thenReturn("https://integral.example");

        ResponseEntity<String> expected = ResponseEntity.ok("{}");

        when(restTemplate.exchange(
                anyString(),
                eq(HttpMethod.GET),
                eq(HttpEntity.EMPTY),
                eq(String.class)
        )).thenReturn(expected);

        ResponseEntity<String> actual = api.queryByClientId("CL-123");

        assertSame(expected, actual);

        ArgumentCaptor<String> urlCaptor = ArgumentCaptor.forClass(String.class);
        verify(restTemplate).exchange(
                urlCaptor.capture(),
                eq(HttpMethod.GET),
                eq(HttpEntity.EMPTY),
                eq(String.class)
        );

        assertEquals(
                "https://integral.example/v2/rfs?clOrderId=CL-123",
                urlCaptor.getValue()
        );
    }

    @Test
    void queryByServerId_buildsExpectedUrlAndGetRequest() {
        when(applicationConfig.getBaseUrl()).thenReturn("https://integral.example");

        ResponseEntity<String> expected =
                ResponseEntity.ok("{\"event\":\"QUOTE\"}");

        when(restTemplate.exchange(
                anyString(),
                eq(HttpMethod.GET),
                eq(HttpEntity.EMPTY),
                eq(String.class)
        )).thenReturn(expected);

        ResponseEntity<String> actual = api.queryByServerId("REQ-456");

        assertSame(expected, actual);

        ArgumentCaptor<String> urlCaptor = ArgumentCaptor.forClass(String.class);
        verify(restTemplate).exchange(
                urlCaptor.capture(),
                eq(HttpMethod.GET),
                eq(HttpEntity.EMPTY),
                eq(String.class)
        );

        assertEquals(
                "https://integral.example/v2/rfs/REQ-456",
                urlCaptor.getValue()
        );
    }
}
