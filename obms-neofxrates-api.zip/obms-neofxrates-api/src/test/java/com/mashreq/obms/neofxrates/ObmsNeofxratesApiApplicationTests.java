package com.mashreq.obms.neofxrates;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ObmsNeofxratesApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
