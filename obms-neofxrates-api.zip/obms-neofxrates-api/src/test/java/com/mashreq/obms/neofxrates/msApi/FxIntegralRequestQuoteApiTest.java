package com.mashreq.obms.neofxrates.msApi;

import com.mashreq.obms.neofxrates.config.ApplicationConfig;
import com.mashreq.obms.neofxrates.dto.RequestQuoteRequest;
import com.mashreq.obms.neofxrates.dto.RequestQuoteResponse;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class FxIntegralRequestQuoteApiTest {

    @Mock
    private ApplicationConfig applicationConfig;

    @Mock
    private RestTemplate restTemplate;

    @InjectMocks
    private FxIntegralRequestQuoteApi api;

    @Test
    void requestQuote_callsRfsPostEndpointWithRequestBody() {
        when(applicationConfig.getBaseUrl()).thenReturn("https://integral.example");

        RequestQuoteRequest request = new RequestQuoteRequest();

        RequestQuoteResponse body = new RequestQuoteResponse();
        body.setRequestId("REQ-1");
        ResponseEntity<RequestQuoteResponse> expected =
                ResponseEntity.status(HttpStatus.ACCEPTED).body(body);

        when(restTemplate.exchange(
                anyString(),
                eq(HttpMethod.POST),
                any(HttpEntity.class),
                eq(RequestQuoteResponse.class)
        )).thenReturn(expected);

        ResponseEntity<RequestQuoteResponse> actual = api.requestQuote(request);

        assertSame(expected, actual);

        ArgumentCaptor<String> urlCaptor = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<HttpEntity> entityCaptor = ArgumentCaptor.forClass(HttpEntity.class);

        verify(restTemplate).exchange(
                urlCaptor.capture(),
                eq(HttpMethod.POST),
                entityCaptor.capture(),
                eq(RequestQuoteResponse.class)
        );

        assertEquals(
                "https://integral.example/v2/rfs",
                urlCaptor.getValue()
        );
        assertSame(request, entityCaptor.getValue().getBody());

        // Content-Type is deliberately not hard-coded in the API class.
        assertEquals(0, entityCaptor.getValue().getHeaders().size());
    }
}
