package com.mashreq.obms.neofxrates.hmac;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpRequest;
import org.springframework.http.MediaType;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpResponse;

import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.isNull;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class IntegralHmacInterceptorTest {

    @Mock
    private IntegralHmacProperties properties;

    @Mock
    private IntegralHmacService hmacService;

    @Mock
    private ClientHttpRequestExecution execution;

    @Mock
    private ClientHttpResponse expectedResponse;


    @Test
    void intercept_whenDisabled_passesRequestWithoutGeneratingHeaders()
            throws Exception {

        // Arrange
        when(properties.isEnabled()).thenReturn(false);

        HttpRequest request = new MockHttpRequest(
                HttpMethod.GET,
                URI.create("https://example.com/v2/rfs")
        );

        byte[] body = "{}".getBytes(StandardCharsets.UTF_8);

        when(execution.execute(request, body))
                .thenReturn(expectedResponse);

        // Act
        ClientHttpResponse actual =
                new IntegralHmacInterceptor(properties, hmacService)
                        .intercept(request, body, execution);

        // Assert
        assertSame(expectedResponse, actual);

        verifyNoInteractions(hmacService);
        verify(execution).execute(request, body);
    }


    @Test
    void intercept_whenEnabled_setsHmacHeadersAndExecutes()
            throws Exception {

        // Arrange
        when(properties.isEnabled()).thenReturn(true);

        HttpRequest request = new MockHttpRequest(
                HttpMethod.POST,
                URI.create("https://example.com/v2/rfs")
        );

        request.getHeaders().setContentType(MediaType.APPLICATION_JSON);

        byte[] body = "{\"x\":1}".getBytes(StandardCharsets.UTF_8);

        HmacResponse hmacResponse = new HmacResponse();
        hmacResponse.setDate("date");
        hmacResponse.setDigest("digest");
        hmacResponse.setType("hmac");
        hmacResponse.setAuthorization("authorization");

        when(hmacService.generateHmacHeaders(
                eq(HttpMethod.POST),
                eq("https://example.com/v2/rfs"),
                eq("{\"x\":1}"),
                eq("application/json")
        )).thenReturn(hmacResponse);

        when(execution.execute(request, body))
                .thenReturn(expectedResponse);

        // Act
        ClientHttpResponse actual =
                new IntegralHmacInterceptor(properties, hmacService)
                        .intercept(request, body, execution);

        // Assert
        assertSame(expectedResponse, actual);

        assertEquals(
                "date",
                request.getHeaders().getFirst(HttpHeaders.DATE)
        );

        assertEquals(
                "digest",
                request.getHeaders().getFirst("Digest")
        );

        assertEquals(
                "hmac",
                request.getHeaders().getFirst("type")
        );

        assertEquals(
                "authorization",
                request.getHeaders().getFirst(HttpHeaders.AUTHORIZATION)
        );

        verify(hmacService).generateHmacHeaders(
                eq(HttpMethod.POST),
                eq("https://example.com/v2/rfs"),
                eq("{\"x\":1}"),
                eq("application/json")
        );

        verify(execution).execute(request, body);
    }


    @Test
    void intercept_whenEnabled_withNullBody_passesEmptyBodyToHmacService()
            throws Exception {

        // Arrange
        when(properties.isEnabled()).thenReturn(true);

        HttpRequest request = new MockHttpRequest(
                HttpMethod.GET,
                URI.create("https://example.com/v2/rfs")
        );

        HmacResponse hmacResponse = new HmacResponse();
        hmacResponse.setDate("date");
        hmacResponse.setDigest("digest");
        hmacResponse.setType("hmac");
        hmacResponse.setAuthorization("authorization");

        when(hmacService.generateHmacHeaders(
                eq(HttpMethod.GET),
                eq("https://example.com/v2/rfs"),
                eq(""),
                isNull()
        )).thenReturn(hmacResponse);

        when(execution.execute(request, null))
                .thenReturn(expectedResponse);

        // Act
        ClientHttpResponse actual =
                new IntegralHmacInterceptor(properties, hmacService)
                        .intercept(request, null, execution);

        // Assert
        assertSame(expectedResponse, actual);

        verify(hmacService).generateHmacHeaders(
                eq(HttpMethod.GET),
                eq("https://example.com/v2/rfs"),
                eq(""),
                isNull()
        );

        verify(execution).execute(request, null);
    }


    @Test
    void intercept_whenEnabled_withoutContentType_passesNullContentType()
            throws Exception {

        // Arrange
        when(properties.isEnabled()).thenReturn(true);

        HttpRequest request = new MockHttpRequest(
                HttpMethod.GET,
                URI.create("https://example.com/v2/rfs")
        );

        byte[] body = "test".getBytes(StandardCharsets.UTF_8);

        HmacResponse hmacResponse = new HmacResponse();
        hmacResponse.setDate("date");
        hmacResponse.setDigest("digest");
        hmacResponse.setType("hmac");
        hmacResponse.setAuthorization("authorization");

        when(hmacService.generateHmacHeaders(
                eq(HttpMethod.GET),
                eq("https://example.com/v2/rfs"),
                eq("test"),
                isNull()
        )).thenReturn(hmacResponse);

        when(execution.execute(request, body))
                .thenReturn(expectedResponse);

        // Act
        ClientHttpResponse actual =
                new IntegralHmacInterceptor(properties, hmacService)
                        .intercept(request, body, execution);

        // Assert
        assertSame(expectedResponse, actual);

        verify(hmacService).generateHmacHeaders(
                eq(HttpMethod.GET),
                eq("https://example.com/v2/rfs"),
                eq("test"),
                isNull()
        );

        verify(execution).execute(request, body);
    }


    @Test
    void intercept_whenEnabled_preservesOriginalRequestBody()
            throws Exception {

        // Arrange
        when(properties.isEnabled()).thenReturn(true);

        HttpRequest request = new MockHttpRequest(
                HttpMethod.POST,
                URI.create("https://example.com/v2/rfs")
        );

        byte[] body = "{\"amount\":100}".getBytes(StandardCharsets.UTF_8);

        HmacResponse hmacResponse = new HmacResponse();
        hmacResponse.setDate("date");
        hmacResponse.setDigest("digest");
        hmacResponse.setType("hmac");
        hmacResponse.setAuthorization("authorization");

        when(hmacService.generateHmacHeaders(
                eq(HttpMethod.POST),
                eq("https://example.com/v2/rfs"),
                eq("{\"amount\":100}"),
                isNull()
        )).thenReturn(hmacResponse);

        when(execution.execute(request, body))
                .thenReturn(expectedResponse);

        // Act
        ClientHttpResponse actual =
                new IntegralHmacInterceptor(properties, hmacService)
                        .intercept(request, body, execution);

        // Assert
        assertSame(expectedResponse, actual);

        verify(execution).execute(request, body);
    }


    /**
     * Simple HttpRequest implementation used only for unit testing.
     *
     * Spring's HttpRequest interface in the project's Spring version
     * also requires getAttributes(), so it is implemented here.
     */
    private static class MockHttpRequest implements HttpRequest {

        private final HttpMethod method;
        private final URI uri;
        private final HttpHeaders headers = new HttpHeaders();
        private final Map<String, Object> attributes = new HashMap<>();

        MockHttpRequest(HttpMethod method, URI uri) {
            this.method = method;
            this.uri = uri;
        }

        @Override
        public HttpMethod getMethod() {
            return method;
        }

        @Override
        public URI getURI() {
            return uri;
        }

        @Override
        public HttpHeaders getHeaders() {
            return headers;
        }

        @Override
        public Map<String, Object> getAttributes() {
            return attributes;
        }
    }
}