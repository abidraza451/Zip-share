package com.mashreq.obms.neofxrates.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mashreq.obms.neofxrates.config.DirectDealLoginProperties;
import com.mashreq.obms.neofxrates.dto.DirectDealRequest;
import com.mashreq.obms.neofxrates.dto.DirectDealResponse;
import com.mashreq.obms.neofxrates.msApi.FxIntegralBookTradeApi;
import com.mashreq.obms.neofxrates.msApi.FxIntegralLoginApi;
import com.mashreq.obms.neofxrates.msApi.FxIntegralPlaceOrderApi;
import com.mashreq.obms.neofxrates.msApi.FxIntegralQueryOrderApi;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpHeaders;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class DirectDealServiceTest {

    @Mock
    private FxIntegralLoginApi loginApi;

    @Mock
    private FxIntegralPlaceOrderApi placeOrderApi;

    @Mock
    private FxIntegralQueryOrderApi queryOrderApi;

    @Mock
    private FxIntegralBookTradeApi bookTradeApi;

    private DirectDealService service;

    @BeforeEach
    void setUp() {
        DirectDealLoginProperties loginProperties =
                new DirectDealLoginProperties();
        loginProperties.setUser("prov");
        loginProperties.setPass("Forex1234$");
        loginProperties.setOrg("NEOFX");

        service = new DirectDealService(
                loginApi,
                placeOrderApi,
                queryOrderApi,
                bookTradeApi,
                loginProperties,
                new ObjectMapper());
    }

    @Test
    void customParametersDeserializePostmanFieldNames() throws Exception {
        ObjectMapper mapper = new ObjectMapper();
        String json = "{\"customParameters\":{"
                + "\"CIF\":\"1234553\","
                + "\"Channel\":\"RBG-SWIFT\","
                + "\"Settlement\":\"NOSTRO\","
                + "\"OBDXRef\":\"XX12345\","
                + "\"OBPRef\":\"xx12345\","
                + "\"Reversal\":\"TRUE\"}}";

        DirectDealRequest request = mapper.readValue(json, DirectDealRequest.class);

        assertEquals("RBG-SWIFT", request.getCustomParameters().getChannel());
        assertEquals("1234553", request.getCustomParameters().getCif());
        assertEquals("NOSTRO", request.getCustomParameters().getSettlement());
        assertEquals("XX12345", request.getCustomParameters().getObdxRef());
        assertEquals("xx12345", request.getCustomParameters().getObpRef());
        assertEquals("TRUE", request.getCustomParameters().getReversal());
    }

    @Test
    void placeOrderResponseAcceptsFullIntegralResponse() throws Exception {
        ObjectMapper mapper = new ObjectMapper();
        String json = "{"
                + "\"coId\":\"1790154367902\","
                + "\"type\":\"AtBest\","
                + "\"timeInForce\":\"FOK\","
                + "\"side\":\"Buy\","
                + "\"currency\":\"EUR\","
                + "\"symbol\":\"EUR/AED\","
                + "\"size\":1000.0,"
                + "\"org\":\"NEOFX\","
                + "\"customerOrgName\":\"NEOFX\","
                + "\"account\":\"NEOFX\","
                + "\"clientOrderTime\":\"2026-09-23 09:06:08,517 +0000\","
                + "\"tradeChannel\":\"API/REST/ESP\","
                + "\"orderId\":\"1761137595\","
                + "\"valueDate\":\"2026-09-25\","
                + "\"userFullName\":\"CIBGAPI@CIBGSD\","
                + "\"action\":\"place\","
                + "\"status\":\"RECEIVED\","
                + "\"customParameters\":{\"Channel\":\"RBG-SWIFT\"}"
                + "}";

        var order = mapper.readValue(json,
                com.mashreq.obms.neofxrates.dto.DirectDealOrderResponse.class);

        assertEquals("1761137595", order.getOrderId());
        assertEquals("1790154367902", order.getCoId());
        assertEquals("AtBest", order.getType());
        assertEquals("FOK", order.getTimeInForce());
        assertEquals("EUR/AED", order.getSymbol());
        assertEquals("RECEIVED", order.getStatus());
        assertEquals(new BigDecimal("1000.0"), order.getSize());
        assertEquals("2026-09-25", order.getValueDate());
    }

    @Test
    void directDeal_executesLoginPlaceQueryAndBookTradeInOrder() {
        when(loginApi.loginForDirectDeal(any())).thenReturn(
                ResponseEntity.ok()
                        .header("SSO_TOKEN", "TEST-SSO-TOKEN")
                        .body(new com.mashreq.obms.neofxrates.dto.LoginResponse() {{
                            setStatus("OK");
                        }}));

        when(placeOrderApi.placeOrderWithSso(any(), anyString()))
                .thenAnswer(invocation -> {
                    var orderRequest = invocation.getArgument(0, com.mashreq.obms.neofxrates.dto.DirectDealPlaceOrderRequest.class);
                    return ResponseEntity.ok("{\"orderId\":\"ORD-123\",\"coId\":\"" + orderRequest.getCoId() + "\",\"status\":\"NEW\"}");
                });

        when(queryOrderApi.queryOrderWithSso(eq("ORD-123"), anyString()))
                .thenReturn(ResponseEntity.ok(
                        "[{\"orderId\":\"ORD-123\",\"status\":\"FILLED\","
                                + "\"cumQty\":5000.0,\"averagePrice\":1.19610,"
                                + "\"tradeDate\":\"2026-09-23\"}]"));

        when(bookTradeApi.bookTradeWithSso(any(), anyString()))
                .thenReturn(ResponseEntity.ok(
                        "{\"tradeId\":\"TRD-123\",\"clientRequestId\":\"CR-123\"}"));

        ResponseEntity<DirectDealResponse> response = service.directDeal(validRequest());

        assertEquals(200, response.getStatusCode().value());
        assertEquals("TRD-123", response.getBody().getData().getTradeId());

        var inOrder = inOrder(loginApi, placeOrderApi, queryOrderApi, bookTradeApi);
        inOrder.verify(loginApi).loginForDirectDeal(any());
        inOrder.verify(placeOrderApi).placeOrderWithSso(any(), anyString());
        inOrder.verify(queryOrderApi).queryOrderWithSso(eq("ORD-123"), anyString());
        inOrder.verify(bookTradeApi).bookTradeWithSso(any(), anyString());
    }

    @Test
    void directDealBuildsPlaceOrderPayloadLikePostmanCollection() {
        when(loginApi.loginForDirectDeal(any())).thenReturn(
                ResponseEntity.ok()
                        .header("SSO_TOKEN", "TEST-SSO-TOKEN")
                        .body(new com.mashreq.obms.neofxrates.dto.LoginResponse() {{
                            setStatus("OK");
                        }}));
        when(placeOrderApi.placeOrderWithSso(any(), anyString()))
                .thenAnswer(invocation -> {
                    var orderRequest = invocation.getArgument(0, com.mashreq.obms.neofxrates.dto.DirectDealPlaceOrderRequest.class);
                    return ResponseEntity.ok("{\"orderId\":\"ORD-123\",\"coId\":\"" + orderRequest.getCoId() + "\"}");
                });
        when(queryOrderApi.queryOrderWithSso(eq("ORD-123"), anyString()))
                .thenReturn(ResponseEntity.ok(
                        "[{\"orderId\":\"ORD-123\",\"status\":\"FILLED\"}]"));
        when(bookTradeApi.bookTradeWithSso(any(), anyString()))
                .thenReturn(ResponseEntity.ok("{\"tradeId\":\"TRD-123\"}"));

        service.directDeal(validRequest());

        ArgumentCaptor<com.mashreq.obms.neofxrates.dto.DirectDealPlaceOrderRequest> captor =
                ArgumentCaptor.forClass(
                        com.mashreq.obms.neofxrates.dto.DirectDealPlaceOrderRequest.class);

        verify(placeOrderApi).placeOrderWithSso(captor.capture(), anyString());

        var order = captor.getValue();
        assertNotNull(order.getCoId());
        assertTrue(order.getCoId().matches("\\d+"));
        assertNotEquals("RFQ_AEDEUR0001", order.getCoId());
        assertEquals("AtBest", order.getType());
        assertEquals("EUR/AED", order.getSymbol());
        assertEquals("Sell", order.getSide());
        assertEquals(new BigDecimal("5000.0"), order.getSize());
        assertEquals("EUR", order.getCurrency());
        assertEquals("FOK", order.getTimeInForce());
        assertNotNull(order.getValueDate());
        assertEquals("NEOFX", order.getOrg());
        assertEquals("NEOFX", order.getAccount());
        assertEquals("RBG-SWIFT", order.getCustomParameters().get("Channel"));
        assertEquals("1234553", order.getCustomParameters().get("CIF"));
        assertEquals("NOSTRO", order.getCustomParameters().get("Settlement"));
        assertEquals("XX12345", order.getCustomParameters().get("OBDXRef"));
        assertEquals("xx12345", order.getCustomParameters().get("OBPRef"));
        assertEquals("TRUE", order.getCustomParameters().get("Reversal"));
    }

    @Test
    void directDealUsesFilledOrderValuesForBookTrade() {
        when(loginApi.loginForDirectDeal(any())).thenReturn(
                ResponseEntity.ok()
                        .header("SSO_TOKEN", "TEST-SSO-TOKEN")
                        .body(new com.mashreq.obms.neofxrates.dto.LoginResponse() {{
                            setStatus("OK");
                        }}));
        when(placeOrderApi.placeOrderWithSso(any(), anyString()))
                .thenAnswer(invocation -> {
                    var orderRequest = invocation.getArgument(0, com.mashreq.obms.neofxrates.dto.DirectDealPlaceOrderRequest.class);
                    return ResponseEntity.ok("{\"orderId\":\"ORD-123\",\"coId\":\"" + orderRequest.getCoId() + "\"}");
                });
        when(queryOrderApi.queryOrderWithSso(eq("ORD-123"), anyString()))
                .thenReturn(ResponseEntity.ok(
                        "[{\"orderId\":\"ORD-123\",\"status\":\"FILLED\","
                                + "\"cumQty\":4999.5,\"averagePrice\":1.19611}]"));
        when(bookTradeApi.bookTradeWithSso(any(), anyString()))
                .thenReturn(ResponseEntity.ok("{\"tradeId\":\"TRD-123\"}"));

        service.directDeal(validRequest());

        ArgumentCaptor<com.mashreq.obms.neofxrates.dto.DirectDealBookTradeRequest> captor =
                ArgumentCaptor.forClass(
                        com.mashreq.obms.neofxrates.dto.DirectDealBookTradeRequest.class);

        verify(bookTradeApi).bookTradeWithSso(captor.capture(), anyString());
        assertEquals(new BigDecimal("4999.5"), captor.getValue().getDealtAmount());
        assertEquals(new BigDecimal("1.19611"), captor.getValue().getCoverRate());
        assertEquals("SELL", captor.getValue().getSide());
        assertEquals("Spot", captor.getValue().getType());
        assertTrue(captor.getValue().getClientRequestId().startsWith("Reversal-"));
        assertNotNull(captor.getValue().getTradeDate());
        assertNotNull(captor.getValue().getValueDate());
    }

    @Test
    void directDealBooksTradeAfterQueryOrderEvenWhenStatusIsNew() {
        when(loginApi.loginForDirectDeal(any())).thenReturn(
                ResponseEntity.ok()
                        .header("SSO_TOKEN", "TEST-SSO-TOKEN")
                        .body(new com.mashreq.obms.neofxrates.dto.LoginResponse() {{
                            setStatus("OK");
                        }}));
        when(placeOrderApi.placeOrderWithSso(any(), anyString()))
                .thenAnswer(invocation -> {
                    var orderRequest = invocation.getArgument(0, com.mashreq.obms.neofxrates.dto.DirectDealPlaceOrderRequest.class);
                    return ResponseEntity.ok("{\"orderId\":\"ORD-123\",\"coId\":\"" + orderRequest.getCoId() + "\",\"status\":\"NEW\"}");
                });
        when(queryOrderApi.queryOrderWithSso(eq("ORD-123"), anyString()))
                .thenReturn(ResponseEntity.ok(
                        "[{\"orderId\":\"ORD-123\",\"status\":\"NEW\",\"averagePrice\":0.0,\"cumQty\":0.0}]"));
        when(bookTradeApi.bookTradeWithSso(any(), anyString()))
                .thenReturn(ResponseEntity.ok("{\"tradeId\":\"TRD-123\"}"));

        ResponseEntity<DirectDealResponse> response = service.directDeal(validRequest());

        assertEquals(200, response.getStatusCode().value());
        assertEquals("TRD-123", response.getBody().getData().getTradeId());
        verify(bookTradeApi).bookTradeWithSso(any(), eq("TEST-SSO-TOKEN"));
    }

    @Test
    void directDealWrapsBookTradeResponseAndRemovesDuplicatedClientRequestId() {
        when(loginApi.loginForDirectDeal(any())).thenReturn(
                ResponseEntity.ok()
                        .header("SSO_TOKEN", "TEST-SSO-TOKEN")
                        .body(new com.mashreq.obms.neofxrates.dto.LoginResponse() {{
                            setStatus("OK");
                        }}));
        when(placeOrderApi.placeOrderWithSso(any(), anyString()))
                .thenReturn(ResponseEntity.ok("{\"orderId\":\"ORD-123\",\"status\":\"NEW\"}"));
        when(queryOrderApi.queryOrderWithSso(eq("ORD-123"), anyString()))
                .thenReturn(ResponseEntity.ok("[{\"orderId\":\"ORD-123\",\"status\":\"FILLED\"}]"));
        when(bookTradeApi.bookTradeWithSso(any(), anyString()))
                .thenReturn(ResponseEntity.ok(
                        "{\"tradeId\":\"TRD-123\",\"createdTime\":\"2026-09-23 17:15:16,515 +0000\",\"clientRequestId\":\"Reversal-FXI3519927366-1790183715932\"}"));

        ResponseEntity<DirectDealResponse> response = service.directDeal(validRequest());

        assertNotNull(response.getBody());
        assertEquals("TRD-123", response.getBody().getData().getTradeId());
        assertEquals("2026-09-23 17:15:16,515 +0000",
                response.getBody().getData().getCreatedTime());
        assertEquals("Reversal-FXI3519927366-1790183715932",
                response.getBody().getData().getClientRequestId());

        assertFalse(response.getBody().getRequestBody().containsKey("tradeId"));
        assertFalse(response.getBody().getRequestBody().containsKey("createdTime"));
        assertFalse(response.getBody().getRequestBody().containsKey("clientRequestId"));
        assertTrue(response.getBody().getRequestBody().containsKey("symbol"));
        assertTrue(response.getBody().getRequestBody().containsKey("referenceId"));

        // The requestBody must contain actual request values, not Jackson
        // JsonNode metadata.
        assertEquals("EUR/AED", response.getBody().getRequestBody().get("symbol"));
        assertEquals("RFQ_AEDEUR0001", response.getBody().getRequestBody().get("coId"));
    }

    private DirectDealRequest validRequest() {
        DirectDealRequest request = new DirectDealRequest();
        request.setCoId("RFQ_AEDEUR0001");
        request.setSymbol("EUR/AED");
        request.setSide("Sell");
        request.setSize(new BigDecimal("5000.0"));
        request.setCurrency("EUR");
        request.setValueDate("2026-09-10");
        request.setOrg("NEOFX");
        request.setAccount("NEOFX");

        DirectDealRequest.CustomParameters custom =
                new DirectDealRequest.CustomParameters();
        custom.setChannel("RBG-SWIFT");
        custom.setCif("1234553");
        custom.setSettlement("NOSTRO");
        custom.setObdxRef("XX12345");
        custom.setObpRef("xx12345");
        custom.setReversal("TRUE");
        request.setCustomParameters(custom);

        request.setSource("OBPAY");
        request.setChannel("1");
        request.setClientRequestId("AcceptFail-FXI3521646481");
        request.setCoverRate(new BigDecimal("1.19598"));
        request.setCreditMode(2);
        request.setCustomerOrg("NEOFX_UAE_CIBG_Regular");
        request.setCustomerAccount("NEOFX_UAE_CIBG_Regular");
        request.setTrader("CIBGRegularAPI");
        request.setDealtAmount(new BigDecimal("5000.0"));
        request.setNote("Acceptance-Failed");
        request.setRate(new BigDecimal("1.19598"));
        request.setRateId("RFQ_AEDEUR0001");
        request.setReferenceId("FXI3522946779");
        request.setSpotRate(new BigDecimal("1.19598"));
        request.setTradeDate("2026-09-08");
        request.setCounterparty("NEOFX");
        request.setCounterpartyAccount("NEOFX");
        request.setCounterpartyTrader("Prov");
        request.setDealtIns("EUR");
        request.setStp(true);
        return request;
    }
}
