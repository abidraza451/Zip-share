package com.mashreq.obms.neofxrates.service;

import com.mashreq.obms.neofxrates.dto.AcceptQuoteRequest;
import com.mashreq.obms.neofxrates.dto.DealBookingRequest;
import com.mashreq.obms.neofxrates.dto.DealBookingResponse;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mashreq.obms.neofxrates.exception.RequestQuoteException;
import com.mashreq.obms.neofxrates.msApi.FxIntegralAcceptQuoteApi;
import com.mashreq.obms.neofxrates.msApi.FxIntegralQueryQuoteApi;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class DealBookingServiceTest {

    @Mock
    private FxIntegralAcceptQuoteApi acceptQuoteApi;

    @Mock
    private FxIntegralQueryQuoteApi queryQuoteApi;

    private DealBookingService service;

    @BeforeEach
    void setUp() {
        service = new DealBookingService(acceptQuoteApi, queryQuoteApi, new ObjectMapper());
    }

    @Test
    void dealBooking_acceptsEmptyAcceptQuoteBody_thenQueriesExactlyOnce() {
        when(acceptQuoteApi.acceptQuote(eq("REQ-123"), any(AcceptQuoteRequest.class)))
                .thenReturn(ResponseEntity.status(HttpStatus.ACCEPTED).build());
        when(queryQuoteApi.queryByServerId("REQ-123"))
                .thenReturn(ResponseEntity.ok("{\"event\":\"QUOTE\",\"quotes\":[{\"id\":\"Q1\"}] }"));

        ResponseEntity<DealBookingResponse> response = service.dealBooking(validRequest());

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("QUOTE", response.getBody().getData().get("event"));
        assertNotNull(response.getBody().getData().get("quotes"));
        assertEquals("12345", response.getBody().getRequestBody().getCif());
        assertEquals("Q-123", response.getBody().getRequestBody().getQuoteId());
        assertEquals("R123456", response.getBody().getRequestBody().getRefNo());
        assertTrue(response.getBody().getRequestBody().getRfq());
        assertEquals("BUY", response.getBody().getRequestBody().getSide());
        assertEquals("OBPAY", response.getBody().getRequestBody().getSource());
        verify(acceptQuoteApi).acceptQuote(eq("REQ-123"), any(AcceptQuoteRequest.class));
        verify(queryQuoteApi, times(1)).queryByServerId("REQ-123");
    }

    @Test
    void dealBooking_acceptQuoteRequestContainsOnlyIntegralFields() {
        when(acceptQuoteApi.acceptQuote(eq("REQ-123"), any(AcceptQuoteRequest.class)))
                .thenReturn(ResponseEntity.status(HttpStatus.ACCEPTED).build());
        when(queryQuoteApi.queryByServerId("REQ-123"))
                .thenReturn(ResponseEntity.ok("{\"event\":\"QUOTE\"}"));

        service.dealBooking(validRequest());

        ArgumentCaptor<AcceptQuoteRequest> captor = ArgumentCaptor.forClass(AcceptQuoteRequest.class);
        verify(acceptQuoteApi).acceptQuote(eq("REQ-123"), captor.capture());
        assertEquals("Q-123", captor.getValue().getQuoteId());
        assertEquals("BUY", captor.getValue().getSide());
        assertEquals("EUR/USD", captor.getValue().getSymbol());
        assertEquals("EUR", captor.getValue().getDealtCurrency());
        assertEquals("TX-123", captor.getValue().getTransactionId());
        assertEquals("view1MultiLP5", captor.getValue().getClOrderId());
        assertTrue(captor.getValue().getRfq());
    }

    @Test
    void dealBooking_doesNotQueryWhenAcceptQuoteFails() {
        when(acceptQuoteApi.acceptQuote(eq("REQ-123"), any(AcceptQuoteRequest.class)))
                .thenReturn(ResponseEntity.status(HttpStatus.BAD_REQUEST).body("failed"));

        RequestQuoteException exception = assertThrows(RequestQuoteException.class,
                () -> service.dealBooking(validRequest()));

        assertEquals("ACCEPT_QUOTE", exception.getStep());
        verify(queryQuoteApi, never()).queryByServerId(anyString());
    }

    @Test
    void dealBooking_rejectsMissingRequestId() {
        DealBookingRequest request = validRequest();
        request.setRequestId(" ");

        RequestQuoteException exception = assertThrows(RequestQuoteException.class,
                () -> service.dealBooking(request));

        assertEquals("VALIDATION", exception.getStep());
        verifyNoInteractions(acceptQuoteApi, queryQuoteApi);
    }

    @Test
    void dealBooking_wrapsQueryQuoteResponseInsideDataAndReturnsOriginalRequestBody() {
        when(acceptQuoteApi.acceptQuote(eq("REQ-123"), any(AcceptQuoteRequest.class)))
                .thenReturn(ResponseEntity.status(HttpStatus.ACCEPTED).build());
        when(queryQuoteApi.queryByServerId("REQ-123"))
                .thenReturn(ResponseEntity.ok(
                        "{\"clOrderId\":\"view1MultiLP5\",\"requestId\":\"REQ-123\",\"event\":\"QUOTE\",\"quotes\":[{\"id\":\"Q1\"}]}"));

        DealBookingRequest request = validRequest();
        ResponseEntity<DealBookingResponse> response = service.dealBooking(request);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("view1MultiLP5", response.getBody().getData().get("clOrderId"));
        assertEquals("REQ-123", response.getBody().getData().get("requestId"));
        assertEquals("QUOTE", response.getBody().getData().get("event"));
        assertNotNull(response.getBody().getData().get("quotes"));
        assertEquals("12345", response.getBody().getRequestBody().getCif());
        assertEquals("Q-123", response.getBody().getRequestBody().getQuoteId());
        assertEquals("R123456", response.getBody().getRequestBody().getRefNo());
        assertTrue(response.getBody().getRequestBody().getRfq());
        assertEquals("BUY", response.getBody().getRequestBody().getSide());
        assertEquals("OBPAY", response.getBody().getRequestBody().getSource());
    }

    @Test
    void dealBooking_rejectsEmptyQueryQuoteBody() {
        when(acceptQuoteApi.acceptQuote(eq("REQ-123"), any(AcceptQuoteRequest.class)))
                .thenReturn(ResponseEntity.status(HttpStatus.ACCEPTED).build());
        when(queryQuoteApi.queryByServerId("REQ-123"))
                .thenReturn(ResponseEntity.ok(""));

        RequestQuoteException exception = assertThrows(RequestQuoteException.class,
                () -> service.dealBooking(validRequest()));

        assertEquals("QUERY_QUOTE", exception.getStep());
    }

    private DealBookingRequest validRequest() {
        DealBookingRequest request = new DealBookingRequest();
        request.setRequestId("REQ-123");
        request.setQuoteId("Q-123");
        request.setSide("BUY");
        request.setSymbol("EUR/USD");
        request.setDealtCurrency("EUR");
        request.setTransactionId("TX-123");
        request.setClOrderId("view1MultiLP5");
        request.setRfq(true);
        request.setCif("12345");
        request.setRefNo("R123456");
        request.setSource("OBPAY");
        return request;
    }
}
