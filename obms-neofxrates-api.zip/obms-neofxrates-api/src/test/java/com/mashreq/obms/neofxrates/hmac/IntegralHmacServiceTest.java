package com.mashreq.obms.neofxrates.hmac;

import org.junit.jupiter.api.*;
import org.springframework.http.HttpMethod;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;
import static org.junit.jupiter.api.Assertions.*;

class IntegralHmacServiceTest {

    private IntegralHmacProperties properties;
    private IntegralHmacService service;

    @BeforeEach
    void setUp() {
        properties = new IntegralHmacProperties();
        properties.setEnabled(true);
        properties.setUsername("test-user");
        properties.setSecret("test-secret");
        properties.setSecretEncoding("utf8");
        properties.setStripPathPrefix("/v2");
        properties.setHeaders("date request-line digest");
        properties.setBodyLineEnding("lf");
        service = new IntegralHmacService(properties);
    }

    @Test
    void generateHmacHeaders_generatesExpectedStructureAndDigest() throws Exception {
        String body = "{\"amount\":100}";
        HmacResponse response = service.generateHmacHeaders(
                HttpMethod.POST,
                "https://example.com/v2/rfs?x=1",
                body,
                "application/json");

        String expectedDigest = Base64.getEncoder().encodeToString(
                MessageDigest.getInstance("SHA-256")
                        .digest(body.getBytes(StandardCharsets.UTF_8)));

        assertEquals("test-user", response.getUsername());
        assertNotNull(response.getDate());
        assertEquals(expectedDigest, response.getDigest());
        assertEquals("hmac", response.getType());
        assertEquals("POST /rfs?x=1 HTTP/1.1", response.getRequestLine());
        assertTrue(response.getSigningString().contains("date: " + response.getDate()));
        assertTrue(response.getSigningString().contains("digest: " + expectedDigest));
        assertNotNull(response.getSignature());
        assertTrue(response.getAuthorization().contains("username=\"test-user\""));
        assertTrue(response.getAuthorization().contains("algorithm=\"hmac-sha256\""));
        assertTrue(response.getAuthorization().contains("headers=\"date request-line digest\""));
    }

    @Test
    void generateHmacHeaders_defaultsNullBodyToEmptyBody() throws Exception {
        HmacResponse response = service.generateHmacHeaders(
                HttpMethod.GET, "https://example.com/v2/rfs", null, null);

        String expectedDigest = Base64.getEncoder().encodeToString(
                MessageDigest.getInstance("SHA-256")
                        .digest(new byte[0]));

        assertEquals(expectedDigest, response.getDigest());
        assertEquals("GET /rfs HTTP/1.1", response.getRequestLine());
    }

    @Test
    void generateHmacHeaders_crlfNormalizesBodyBeforeDigest() throws Exception {
        properties.setBodyLineEnding("crlf");

        HmacResponse response = service.generateHmacHeaders(
                HttpMethod.POST, "https://example.com/v2/rfs", "a\nb\r\nc", "application/json");

        String normalized = "a\r\nb\r\nc";
        String expectedDigest = Base64.getEncoder().encodeToString(
                MessageDigest.getInstance("SHA-256")
                        .digest(normalized.getBytes(StandardCharsets.UTF_8)));

        assertEquals(expectedDigest, response.getDigest());
    }

    @Test
    void generateHmacHeaders_emptyConfiguredHeaders_usesDefaults() {
        properties.setHeaders(" ");
        HmacResponse response = service.generateHmacHeaders(
                HttpMethod.GET, "https://example.com/v2/rfs", "", null);

        assertEquals("date request-line digest", response.getAuthorization().split("headers=\"")[1].split("\"")[0]);
    }

    @Test
    void generateHmacHeaders_customHeaders_supportsContentTypeAndContentLength() {
        properties.setHeaders("date request-line digest content-type content-length");

        HmacResponse response = service.generateHmacHeaders(
                HttpMethod.POST, "https://example.com/v2/rfs", "abc", "application/json");

        assertTrue(response.getSigningString().contains("content-type: application/json"));
        assertTrue(response.getSigningString().contains("content-length: 3"));
    }

    @Test
    void generateHmacHeaders_withoutStripPrefix_keepsV2Path() {
        properties.setStripPathPrefix(null);

        HmacResponse response = service.generateHmacHeaders(
                HttpMethod.GET, "https://example.com/v2/rfs", "", null);

        assertEquals("GET /v2/rfs HTTP/1.1", response.getRequestLine());
    }

    @Test
    void generateHmacHeaders_nullMethod_throwsException() {
        assertThrows(IllegalArgumentException.class,
                () -> service.generateHmacHeaders(null, "https://example.com/v2/rfs", "", null));
    }

    @Test
    void generateHmacHeaders_blankUrl_throwsException() {
        assertThrows(IllegalArgumentException.class,
                () -> service.generateHmacHeaders(HttpMethod.GET, " ", "", null));
    }

    @Test
    void generateHmacHeaders_missingUsername_throwsException() {
        properties.setUsername(" ");
        assertThrows(IllegalStateException.class,
                () -> service.generateHmacHeaders(HttpMethod.GET, "https://example.com/v2/rfs", "", null));
    }

    @Test
    void generateHmacHeaders_missingSecret_throwsException() {
        properties.setSecret(null);
        assertThrows(IllegalStateException.class,
                () -> service.generateHmacHeaders(HttpMethod.GET, "https://example.com/v2/rfs", "", null));
    }

    @Test
    void generateHmacHeaders_invalidBase64Secret_throwsException() {
        properties.setSecretEncoding("base64");
        properties.setSecret("%%%not-base64%%%");

        assertThrows(IllegalStateException.class,
                () -> service.generateHmacHeaders(HttpMethod.GET, "https://example.com/v2/rfs", "", null));
    }

    @Test
    void generateHmacHeaders_urlWithoutPath_usesRootPath() {
        HmacResponse response = service.generateHmacHeaders(
                HttpMethod.GET, "https://example.com", "", null);

        assertEquals("GET / HTTP/1.1", response.getRequestLine());
    }

    @Test
    void generateHmacHeaders_unknownConfiguredHeader_createsEmptyHeaderLine() {
        properties.setHeaders("date x-custom digest");

        HmacResponse response = service.generateHmacHeaders(
                HttpMethod.GET, "https://example.com/v2/rfs", "", null);

        assertTrue(response.getSigningString().contains("x-custom: "));
    }
}
