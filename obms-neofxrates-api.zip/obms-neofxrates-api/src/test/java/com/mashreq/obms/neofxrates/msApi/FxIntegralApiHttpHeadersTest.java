package com.mashreq.obms.neofxrates.msApi;

import com.mashreq.obms.neofxrates.config.ApplicationConfig;
import com.mashreq.obms.neofxrates.dto.LoginRequest;
import com.mashreq.obms.neofxrates.dto.LoginResponse;
import com.mashreq.obms.neofxrates.dto.RequestQuoteRequest;
import com.mashreq.obms.neofxrates.dto.RequestQuoteResponse;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.web.client.MockRestServiceServer;
import org.springframework.web.client.RestTemplate;

import static org.springframework.test.web.client.match.MockRestRequestMatchers.content;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.header;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.method;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.requestTo;
import static org.springframework.test.web.client.response.MockRestResponseCreators.withSuccess;
import static org.junit.jupiter.api.Assertions.assertEquals;

class FxIntegralApiHttpHeadersTest {

    @Test
    void login_restTemplateDeterminesJsonContentTypeFromRequestBody() {
        ApplicationConfig applicationConfig = new ApplicationConfig();
        applicationConfig.setBaseUrl("https://integral.example");

        RestTemplate restTemplate = new RestTemplate();
        MockRestServiceServer server = MockRestServiceServer.bindTo(restTemplate).build();

        server.expect(requestTo("https://integral.example/v2/sso/login"))
                .andExpect(method(org.springframework.http.HttpMethod.POST))
                .andExpect(header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE))
                .andExpect(content().json("{\"user\":\"u\",\"pass\":\"p\",\"org\":\"o\"}"))
                .andRespond(withSuccess("{\"status\":\"OK\"}", MediaType.APPLICATION_JSON));

        FxIntegralLoginApi api = new FxIntegralLoginApi(applicationConfig, restTemplate);

        LoginRequest request = new LoginRequest();
        request.setUser("u");
        request.setPass("p");
        request.setOrg("o");

        LoginResponse response = api.login(request).getBody();

        assertEquals("OK", response.getStatus());
        server.verify();
    }

    @Test
    void requestQuote_restTemplateDeterminesJsonContentTypeFromRequestBody() {
        ApplicationConfig applicationConfig = new ApplicationConfig();
        applicationConfig.setBaseUrl("https://integral.example");

        RestTemplate restTemplate = new RestTemplate();
        MockRestServiceServer server = MockRestServiceServer.bindTo(restTemplate).build();

        server.expect(requestTo("https://integral.example/v2/rfs"))
                .andExpect(method(org.springframework.http.HttpMethod.POST))
                .andExpect(header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE))
                .andRespond(withSuccess("{\"requestId\":\"REQ-1\"}", MediaType.APPLICATION_JSON));

        FxIntegralRequestQuoteApi api =
                new FxIntegralRequestQuoteApi(applicationConfig, restTemplate);

        RequestQuoteResponse response =
                api.requestQuote(new RequestQuoteRequest()).getBody();

        assertEquals("REQ-1", response.getRequestId());
        server.verify();
    }
}
