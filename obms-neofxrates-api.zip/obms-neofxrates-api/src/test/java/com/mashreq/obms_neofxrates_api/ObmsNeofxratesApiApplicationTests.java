package com.mashreq.obms_neofxrates_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ObmsNeofxratesApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
