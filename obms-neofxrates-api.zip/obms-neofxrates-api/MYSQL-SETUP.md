# Local MySQL setup

Create/use the local schema:

```sql
CREATE DATABASE IF NOT EXISTS neo_fx;
USE neo_fx;
```

The application uses:

```text
jdbc:mysql://localhost:3306/neo_fx
```

Set the local MySQL username/password in `application-local.yaml` (or use your environment variables if configured).

Hibernate is configured with `ddl-auto: update`, so the `currency_pair` table is created from the JPA entity.

## Initial currency-pair directions

The local seed file contains these business-configured directions:

```text
EUR/USD
GBP/USD
USD/INR
USD/AED
GBP/EUR
EUR/INR
GBP/INR
EUR/AED
GBP/AED
USD/JPY
```

The database direction is always the Integral symbol direction: `BASE/QUOTE`.
The service first looks for `debitCurrency/transferCurrency`; if that is not configured, it looks for the reverse pair.

## Inverse calculation

The dealt currency is selected from `payByIndicator`:

- `D` -> dealt currency = debit currency
- `T` -> dealt currency = transfer currency

For the resolved symbol:

- BASE = dealt currency -> `inverse = N`
- QUOTE = dealt currency -> `inverse = Y`

The response calculation is:

```text
inverse = N: settledAmount = dealtAmount * rate
inverse = Y: settledAmount = dealtAmount / rate
reciprocalRate = 1 / rate
```
