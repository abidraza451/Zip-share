# Integral RFQ / HMAC setup

This project follows the supplied working Postman RFQ flow:

1. `POST /v2/sso/login`
2. Save `SSO_TOKEN` from the login response headers.
3. Preserve `Set-Cookie` values returned by login and carry them to the RFQ request.
4. `POST /v2/rfs` with HMAC authentication. The RFQ request does not add `SSO_TOKEN`; session cookies are carried forward.
5. Wait once (20 seconds in the service).
6. Make exactly one `GET /v2/rfs/{requestId}` query using the request ID returned by Request Quote and the `SSO_TOKEN` plus session cookies.

## HMAC configuration

Set these environment variables in IntelliJ or the deployment environment:

```text
INTEGRAL_HMAC_USERNAME=CIBGAPI@CIBGSD
INTEGRAL_HMAC_SECRET=<your Integral HMAC secret>
```

The secret is intentionally not committed to source control.

The signing rules match the supplied Postman collection:

- `Date`: current UTC RFC-1123 date
- `Digest`: raw Base64(SHA-256(request body)); no `SHA-256=` prefix
- `type: hmac`
- request-line strips `/v2`
- signed headers: `date request-line digest`
- HMAC-SHA256 with the raw UTF-8 secret by default
- Authorization parameter is `username`

## RFQ payload alignment

The internal Request Quote DTO sends `rfq` as the JSON string `"true"`/`"false"`, matching the supplied working Postman HMAC request. Null optional fields are omitted.

The service defaults missing values to the working RFQ defaults:

- `rfq`: `"true"`
- `expiry`: `120`
- `priceType`: `Spot`
- `nearValueDate`: `Spot`

`customerAccount` and `customerOrg` remain required inputs so the calling application controls the customer routing.


## Gateway session cookie

Postman automatically maintains cookies. This project carries `Set-Cookie` values returned by login/request responses into the following RFQ calls. If the UAT gateway also requires a pre-existing sticky-session cookie (for example, the Postman console showed `sso_sticky_session_apigateway=apigateway2`), set:

```text
INTEGRAL_INITIAL_COOKIES=sso_sticky_session_apigateway=apigateway2
```

Do not hard-code a gateway-specific sticky cookie unless the environment requires it.
