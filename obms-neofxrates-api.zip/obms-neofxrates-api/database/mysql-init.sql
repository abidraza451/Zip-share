-- Local MySQL setup for obms-neofxrates-api.
CREATE DATABASE IF NOT EXISTS neo_fx;
USE neo_fx;

CREATE TABLE IF NOT EXISTS currency_pair (
    id BIGINT NOT NULL AUTO_INCREMENT,
    base_currency VARCHAR(3) NOT NULL,
    quote_currency VARCHAR(3) NOT NULL,
    PRIMARY KEY (id),
    CONSTRAINT unique_pair UNIQUE (base_currency, quote_currency)
);

-- Initial local-development directions.
-- BASE is the business-configured stronger currency and QUOTE is the weaker currency.
INSERT IGNORE INTO currency_pair (base_currency, quote_currency)
VALUES
    ('EUR', 'USD'),
    ('GBP', 'USD'),
    ('USD', 'INR'),
    ('USD', 'AED'),
    ('GBP', 'EUR'),
    ('EUR', 'INR'),
    ('GBP', 'INR'),
    ('EUR', 'AED'),
    ('GBP', 'AED'),
    ('USD', 'JPY');
