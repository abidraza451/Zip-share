# Direct Deal API

## Endpoint

`POST /neoFx/directDeal`

The incoming Direct Deal JSON contract is kept unchanged. The service executes the
same logical sequence as the Postman **Reversals Workflow**:

1. `POST /v2/sso/login` — Direct Deal login using the incoming/configured user,
   password and org. The `SSO_TOKEN` response header is captured.
2. `POST /v2/orders` — Place Order (`AtBest`, `FOK`) using the captured `SSO_TOKEN`.
3. `GET /v2/orders/{orderId}` — **one single Query Order call** using the **orderId
   returned by Place Order**, authenticated with the same `SSO_TOKEN`.
4. `POST /v2/trades` — Book Trade only after the single Query Order response is
   `FILLED`, authenticated with the same `SSO_TOKEN`.
5. The Book Trade response is returned to the caller.

Direct Deal is the only workflow that uses this SSO authentication path. Its requests
carry the `SSO_TOKEN` and explicitly bypass the global HMAC interceptor. Other APIs
continue using their existing HMAC authentication.

## Postman-generated values reproduced in Java

The service keeps the incoming request body/schema unchanged, but reproduces the
Postman pre-request behavior internally:

- `clientOrderId` / Place Order `coId` = current millisecond timestamp.
- Place Order `valueDate` = T+2 business days, skipping Saturday and Sunday.
- Query Order path = `/v2/orders/{orderId}`, where `orderId` is taken directly from
the Place Order response. The incoming `coId` is never used as the Query Order ID.
- Query Order is called exactly once. The returned status is evaluated immediately.
- `REJECTED`, `CANCELED`/`CANCELLED`, `EXPIRED`, or any status other than `FILLED`
  stops the workflow and Book Trade is not called.
- Book Trade `clientRequestId` = `Reversal-<referenceId>-<timestamp>`.
- Book Trade `tradeDate` = today's date.
- Book Trade `valueDate` = the same generated T+2 business date used by Place Order.
- Book Trade `coverRate` uses Query Order `averagePrice` when returned.
- Book Trade `dealtAmount` uses Query Order `cumQty` when returned.

The incoming `valueDate`, `clientRequestId` and `tradeDate` fields remain part of the
request contract for compatibility, but the internally generated values above are
used to match the Postman workflow.

## Login configuration

Configure:

- `INTEGRAL_LOGIN_USER`
- `INTEGRAL_LOGIN_PASSWORD`
- `INTEGRAL_LOGIN_ORG`

The Direct Deal login configuration is:

- `INTEGRAL_LOGIN_USER`
- `INTEGRAL_LOGIN_PASSWORD`
- `INTEGRAL_LOGIN_ORG`

The global HMAC configuration remains available for the other application APIs, but
it is intentionally bypassed for Direct Deal requests. Use environment variables
outside local development.

## Example request

```json
{
  "coId": "RFQ_AEDEUR0001",
  "symbol": "EUR/AED",
  "side": "Sell",
  "size": 5000.0,
  "currency": "EUR",
  "valueDate": "2026-09-10",
  "org": "NEOFX",
  "account": "NEOFX",
  "customParameters": {
    "Channel": "RBG-SWIFT",
    "CIF": "1234553",
    "Settlement": "NOSTRO",
    "OBDXRef": "XX12345",
    "OBPRef": "xx12345",
    "Reversal": "TRUE"
  },
  "source": "OBPAY",
  "channel": "1",
  "clientRequestId": "AcceptFail-FXI3521646481",
  "coverRate": 1.19598,
  "creditMode": 2,
  "customerOrg": "NEOFX_UAE_CIBG_Regular",
  "customerAccount": "NEOFX_UAE_CIBG_Regular",
  "trader": "CIBGRegularAPI",
  "dealtAmount": 5000.0,
  "note": "Acceptance-Failed",
  "rate": 1.19598,
  "rateId": "RFQ_AEDEUR0001",
  "referenceId": "FXI3522946779",
  "spotRate": 1.19598,
  "tradeDate": "2026-09-08",
  "counterparty": "NEOFX",
  "counterpartyAccount": "NEOFX",
  "counterpartyTrader": "Prov",
  "dealtIns": "EUR",
  "stp": true
}
```

The caller-supplied `coverRate` is used as a fallback. When Query Order returns
`averagePrice`, the actual filled `averagePrice` is used for Book Trade. Likewise,
Query Order `cumQty` is used as the booked `dealtAmount` when present.
